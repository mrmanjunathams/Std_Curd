import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './core/guard';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { ForgotpasswordComponent } from './components/forgotpassword/forgotpassword.component';
import { EmailverificationComponent } from './components/emailverification/emailverification.component';
import { ResetpasswordComponent } from './components/resetpassword/resetpassword.component';
import { CustomeremailverifyComponent } from './components/customeremailverify/customeremailverify.component';
import { CustomerresetpwdComponent } from './components/customerresetpwd/customerresetpwd.component';

const routes: Routes = [
  {
    path: '',
    loadChildren: './layouts/layouts.module#LayoutModule',
    canActivate: [AuthGuard]
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'signup',
    component: RegisterComponent
  },
  {
    path: 'forgot',
    component: ForgotpasswordComponent
  },
  {
    path: 'resetpassword',
    component: ResetpasswordComponent
  },
  {
    path: 'emailverify',
    component: EmailverificationComponent
  },
  {
    path: 'verify',
    component: CustomeremailverifyComponent
  },
  {
    path: 'resetpwd',
    component: CustomerresetpwdComponent
  },
  
  { path: '**', redirectTo: 'not-found' }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [AuthGuard]
})
export class AppRoutingModule { }
