import { NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { LayoutRoutingModule } from './layouts-routing.module';
import { ChartsModule as Ng2Charts } from 'ng2-charts';
import { LayoutsComponent } from './layouts.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { NavbarComponent } from '../components/navbar/navbar.component';
import { MaterialModule } from '../core/modules/material/material-material.module';
import { ProfileComponent } from './components/profile/profile.component';
import { ChangePasswordComponent } from '../components/change-password/change-password.component';
import { ListBrandComponent } from './components/brand/list-brand/list-brand.component';
import { PageHeaderComponent } from '../core/modules/page-header/page-header.component';
import { CustomerComponent } from './components/customer/customer.component';
import { ListStoreComponent } from './components/store/list-store/list-store.component';
import { ListStoreAdsComponent } from './components/store/list-store-ads/list-store-ads.component';
import { ListBrandAdsComponent } from './components/brand/list-brand-ads/list-brand-ads.component';
import { CategoryComponent } from './components/category/category.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UserComponent } from './components/user/user.component';
import { StatComponent } from '../core/modules/stat/stat.component';
import { NewUserComponent } from '../core/modules/new-user/new-user.component';
import { NewBrandComponent } from '../core/modules/new-brand/new-brand.component';
import { NewStoreComponent } from '../core/modules/new-store/new-store.component';
import { EditProfileComponent } from './components/profile/edit-profile/edit-profile.component';
import { TagComponent } from './components/tag/tag.component';
import { ViewBrandComponent } from './components/brand/list-brand/view-brand/view-brand.component';
import { CreateBrandComponent } from './components/brand/list-brand/create-brand/create-brand.component';
import { StoreComponent } from './components/brand/brandstore/store.component';
import { BrandadComponent } from './components/brand/brandad/brandad.component';
import { CreatestoreComponent } from './components/brand/brandstore/createstore/createstore.component';
import { CreatebrandadComponent } from './components/brand/brandad/createbrandad/createbrandad.component';
import { OwnBrandstoreComponent } from './components/brand/list-brand/view-brand/own-brandstore/own-brandstore.component';
import { OwnBrandadsComponent } from './components/brand/list-brand/view-brand/own-brandads/own-brandads.component';
import { ViewOwnStoredetailsComponent } from './components/store/view-own-storedetails/view-own-storedetails.component';
import { ListOwnStoreadsComponent } from './components/store/list-own-storeads/list-own-storeads.component';
import { CompaignComponent } from './components/compaign/compaign.component';
import { ViewBrandadComponent } from './components/brand/brandad/view-brandad/view-brandad.component';
// import { BrandUserManagementComponent } from './components/usermanagement/brand-user-management/brand-user-management.component';
// import { CreateBrandUserComponent } from './components/usermanagement/brand-user-management/create-brand-user/create-brand-user.component';
// import { AdminUserManagementComponent } from './components/usermanagement/admin-user-management/admin-user-management.component';
// import { CreateAdminUserComponent } from './components/usermanagement/admin-user-management/create-admin-user/create-admin-user.component';
import { ListMyStoreAdsComponent } from './components/store/store-user/list-my-store-ads/list-my-store-ads.component';
import { CreateMyStoreAdComponent } from './components/store/store-user/list-my-store-ads/create-my-store-ad/create-my-store-ad.component';
// import { StoreUserComponent } from './components/usermanagement/store-user/store-user.component';
import { ViewStoreadsComponent } from './components/store/store-user/view-storeads/view-storeads.component';
import { ListOwnPopadsComponent } from './components/store/list-own-popads/list-own-popads.component';
import { UsermanagementComponent } from './components/usermanagement/usermanagement.component';
import { CreateuserComponent } from './components/usermanagement/createuser/createuser.component';
import { QRCodeModule } from 'angularx-qrcode';
import { QrCodeComponent } from '../core/modules/qr-code/qr-code.component';

@NgModule({
  declarations: [
    LayoutsComponent,
    DashboardComponent, 
    NavbarComponent, 
    ProfileComponent, 
    ChangePasswordComponent, 
    ListBrandComponent, 
    PageHeaderComponent, 
    CustomerComponent, 
    ListStoreComponent, 
    ListStoreAdsComponent, 
    ListBrandAdsComponent, 
    CategoryComponent, 
    UserComponent,
    StatComponent,
    NewUserComponent,
    NewStoreComponent,
    NewBrandComponent,
    EditProfileComponent,
    TagComponent,
    ViewBrandComponent,
    CreateBrandComponent,
    StoreComponent,
    BrandadComponent,
    CreatestoreComponent,
    CreatebrandadComponent,
    OwnBrandstoreComponent,
    OwnBrandadsComponent,
    ViewOwnStoredetailsComponent,
    ListOwnStoreadsComponent,
    ViewBrandadComponent,
    CompaignComponent,
    // BrandUserManagementComponent,
    // CreateBrandUserComponent,
    // AdminUserManagementComponent,
    // CreateAdminUserComponent,
    CreateMyStoreAdComponent,
    ListMyStoreAdsComponent,
    // StoreUserComponent,
    ViewStoreadsComponent,
    ListOwnPopadsComponent,
    UsermanagementComponent,
    CreateuserComponent,
    QrCodeComponent
  ],

  imports: [
    LayoutRoutingModule,
    CommonModule,
    MaterialModule,
    FlexLayoutModule,
    Ng2Charts,
    QRCodeModule,
    FormsModule, ReactiveFormsModule
  ],
})
export class LayoutModule { }
