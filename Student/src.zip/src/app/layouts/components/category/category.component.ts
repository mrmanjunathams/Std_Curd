import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';

import swal from 'sweetalert';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.scss']
})
export class CategoryComponent implements OnInit {

  // modal
  display = 'none';

  addcategory = false;

  public category;

  // datatable
  displayedColumns = ['sno', 'category_name', 'action'];
  dataSource: any;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  // add formGroup
  addcategoryForm: FormGroup;
  submitted = false;

  // update 

  public categorys;
  editcategoryForm: FormGroup;
  public is_active;

  tooltipform = false;


  constructor(private _apiService: ApiService, private router: Router, private formBuilder: FormBuilder) { }

  onclickcategory() {
    this.addcategory = true;
  }

  ngOnInit() {

    this.getcategory();

    // add category formgroup
    this.addcategoryForm = this.formBuilder.group({
      is_active: ['true'],
      category_name: ['', Validators.required],
    });

    // update category formgroup
    this.editcategoryForm = this.formBuilder.group({
      category_id: ['', Validators.required],
      category_name: ['', Validators.required],
    });

  }

  get f() { return this.addcategoryForm.controls; }
  get u() { return this.editcategoryForm.controls; }


  // tag add form

  onclicktooltip() {
    this.tooltipform = true;
  }

  cancel() {
    this.tooltipform = false;
  }

  // model service
  openModal() {
    this.display = 'block';
  }
  onCloseHandled() {
    this.display = 'none';
  }

  // table filter
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  // get category
  getcategory() {
    this._apiService.listcategory("").subscribe(
      res => {
        this.category = res;
        if (this.category.statuscode == 200) {
          this.dataSource = new MatTableDataSource();
          this.dataSource.data = this.category.data;
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
        }
      },
      err => console.error(err)
    );
  }

  // add category

  onSubmit() {
    this.submitted = true;
    if (this.addcategoryForm.valid) {
      this._apiService.categoryadd(this.addcategoryForm.value).subscribe((data: any) => {
        this.cancel();
        this.getcategory();
        if (data.statuscode == 200) {
          this.addcategoryForm.reset();
          swal({
            text: "Category Created Successfully.",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        } else {
          swal({
            text: "Failed to Create Category",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        }
      });
    }
  }

  // edit category

  editcategory(category) {
    this.categorys = category;
    this.editcategoryForm.setValue({
      category_name: this.categorys.category_name,
      category_id: this.categorys.category_id
    });
  }

  // update category
  onUpdate() {
    if (this.editcategoryForm.valid) {
      this._apiService.categoryupdate(this.editcategoryForm.value).subscribe((data: any) => {
        this.getcategory();
        this.onCloseHandled();
        if (data.statuscode == 200) {
          swal({
            text: "Category Updated Successfully.",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        } else {
          swal({
            text: "Failed to Update Category",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        }
      });
    }
  }

  // disable category

  deletecategory(category_id, is_active) {
    // this.is_active = 'false';
    if (category_id && is_active) {
      if (is_active == 'true') {
        swal({
          text: "Are you sure?. Confirm to activate the Category.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.categorydisable(category_id, is_active).subscribe((data: any) => {
                if (data.statuscode = 204) {
                  this.getcategory();
                  swal({
                    text: " Category Activated Successfully",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Activate Category",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      } else {
        swal({
          text: "Are you sure?. Confirm to deactivate the Category.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.categorydisable(category_id, is_active).subscribe((data: any) => {
                if (data.statuscode = 204) {
                  this.getcategory();
                  swal({
                    text: "Category Deactivated Successfully",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Deactivate Category",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      }
    }
  }
}
