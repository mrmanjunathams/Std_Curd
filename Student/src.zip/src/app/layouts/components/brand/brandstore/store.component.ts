import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';

import swal from 'sweetalert';

@Component({
  selector: 'app-store',
  templateUrl: './store.component.html',
  styleUrls: ['./store.component.scss']
})
export class StoreComponent implements OnInit {

  public brandid;
  public brandstoredetails;

  editstoreForm: FormGroup;
  public storedetails;
  public tag;
  public selecttag;
  public updatestore;
  public uploadimage;

  // modal
  display = 'none';

  displayedColumns = ['sno', 'store_name', 'store_email', 'store_phone', 'action'];
  dataSource: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private _apiService: ApiService, private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    const currentUser = JSON.parse(localStorage.getItem('currentuser'));
    this.brandid = currentUser.organisation_id;
    this.getstoredetail();
    this.gettag();

    // update store details formgroup
    // this.editstoreForm = this.formBuilder.group({
    //   store_name: ['', Validators.required],
    //   store_phone: ['', Validators.required],
    //   store_email: ['', Validators.required],
    //   store_id: ['', Validators.required],
    //   store_address: ['', Validators.required],
    //   store_user_name: ['', Validators.required],
    //   tag_id: [''],
    // });
  }

  get f() { return this.editstoreForm.controls; }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  // model service
  openModal() {
    this.display = 'block';
  }
  onCloseHandled() {
    this.display = 'none';
  }

  // get tag
  gettag() {
    this._apiService.listtag('true').subscribe(
      res => {
        this.tag = res;
        if (this.tag.statuscode == 200) {
          this.selecttag = this.tag.data;
        }
      },
      err => console.error(err)
    );
  }

  // get store details

  getstoredetail() {
    if (this.brandid) {
      this._apiService.listbrandstores('', this.brandid).subscribe(
        res => {
          this.brandstoredetails = res;
          if (this.brandstoredetails.statuscode == 200) {
            this.dataSource = new MatTableDataSource();
            this.dataSource.data = this.brandstoredetails.data;
            this.dataSource.sort = this.sort;
            this.dataSource.paginator = this.paginator;
          }
        },
        err => console.error(err)
      );
    }
    else {
      this.dataSource = "No Record found";
    }
  }

  // disable store
  deletestore(store_id, is_active) {
    if (store_id && is_active) {
      if (is_active == 2) {
        swal({
          text: "Are you sure?. Confirm to activate the store.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.storedelete(store_id, is_active).subscribe((data: any) => {
                this.getstoredetail();
                if (data.statuscode = 204) {
                  swal({
                    text: "Store Activated Successfully.",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Store Activation Failed.",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      } else {
        swal({
          text: "Are you sure?. Confirm to deactivate the store.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.storedelete(store_id, is_active).subscribe((data: any) => {
                this.getstoredetail();
                if (data.statuscode = 204) {
                  swal({
                    text: "Store Deactivation Successful.",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Store Deactivation Failed.",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      }
    }
  }

  // view own store detail

  onClickownstoredetails(store_id) {
    if (store_id) {
      localStorage.setItem('store_id', store_id);
      this.router.navigate(['/viewstoredetail'])
    }
  }

}
