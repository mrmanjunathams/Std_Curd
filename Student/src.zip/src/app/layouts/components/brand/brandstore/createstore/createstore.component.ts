import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';

import swal from 'sweetalert';


@Component({
  selector: 'app-createstore',
  templateUrl: './createstore.component.html',
  styleUrls: ['./createstore.component.scss']
})
export class CreatestoreComponent implements OnInit {
  panelOpenState = true;

  public userid;
  public updatestore;
  public uploadimage;
  public tag;
  public selecttag;
  createstoreForm: FormGroup;
  submitted = false;
  @ViewChild('fileInput') fileInput: ElementRef;

  constructor(private _apiService: ApiService, private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    const currentUser = JSON.parse(localStorage.getItem('currentuser'));
    this.userid = currentUser.user_id;

    this.gettag();

    // add store formgroup
    this.createstoreForm = this.formBuilder.group({
      approved_by: [this.userid, Validators.required],
      username: ['', Validators.required],
      mobile_number: ['', [Validators.required, Validators.pattern('[6-9]\\d{9}')]],
      email: ['', [Validators.required, Validators.email]],
      organisation_gst: ['', Validators.required],
      organization_name: ['', Validators.required],
      tag_id: [''],
      brand_id: [this.userid, Validators.required],
    });
  }

  get f() { return this.createstoreForm.controls; }

  // get tag
  gettag() {
    this._apiService.listtag('true').subscribe(
      res => {
        this.tag = res;
        if (this.tag.statuscode == 200) {
          this.selecttag = this.tag.data;
        }
      },
      err => console.error(err)
    );
  }

  // update store image

  fileChange(e) {
    const profiles = e.target.files[0];
    this.updatestore = profiles;
    const reader = new FileReader();
    reader.onload = () => {
      this.uploadimage = reader.result;
    };
    reader.readAsDataURL(profiles);
  }

  // create store

  onSubmit() {
    this.submitted = true;

    if (this.createstoreForm.valid) {
      // const createStore: FormData = new FormData();
      // const file : File = this.updatestore;
      // createStore.append('store_name', this.createstoreForm.value.store_name);
      // createStore.append('brand_id', this.organisationid);
      // createStore.append('store_phone', this.createstoreForm.value.store_phone);
      // createStore.append('store_email', this.createstoreForm.value.store_email);
      // createStore.append('store_address', this.createstoreForm.value.store_address);
      // createStore.append('image', file);
      // createStore.append('user_name', this.createstoreForm.value.store_user_name);
      // createStore.append('tag_id', this.createstoreForm.value.tag_id);
      // createStore.append('store_gst', this.createstoreForm.value.store_gst);
      this._apiService.createstore(this.createstoreForm.value).subscribe((data: any) => {
        if (data.statuscode = 200) {
          this.router.navigate(['/store']);
          this.createstoreForm.reset();
          swal({
            text: "Store Created Successfully",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        } else {
          swal({
            text: "Store Creation Failed!",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        }
      });
    } else {
      swal({
        text: "Some fields are empty.",
        buttons: [false],
        dangerMode: true,
        timer: 3000
      });
    }
  }

}
