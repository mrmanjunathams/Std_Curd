import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewBrandadComponent } from './view-brandad.component';

describe('ViewBrandadComponent', () => {
  let component: ViewBrandadComponent;
  let fixture: ComponentFixture<ViewBrandadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewBrandadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewBrandadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
