import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-brandad',
  templateUrl: './view-brandad.component.html',
  styleUrls: ['./view-brandad.component.scss']
})
export class ViewBrandadComponent implements OnInit {

  public brandadid;
  public brandads;
  public viewbrandads;
  public usertype;

  constructor(private _apiService: ApiService, private router: Router) { }

  ngOnInit() {
    const currentUser = JSON.parse(localStorage.getItem('currentuser'));
    this.usertype = currentUser.user_type;
    this.brandadid = localStorage.getItem('brandad_id')
    this.getcategory();
  }

  // get viewbrandad

  getcategory() {
    this._apiService.listbrandad(this.brandadid).subscribe(
      res => {
        this.brandads = res;
        if (this.brandads.statuscode == 200) {
          this.viewbrandads = this.brandads.data;
        }
      },
      err => console.error(err)
    );
  }


}
