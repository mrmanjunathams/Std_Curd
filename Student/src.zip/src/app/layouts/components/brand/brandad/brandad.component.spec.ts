import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BrandadComponent } from './brandad.component';

describe('BrandadComponent', () => {
  let component: BrandadComponent;
  let fixture: ComponentFixture<BrandadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BrandadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BrandadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
