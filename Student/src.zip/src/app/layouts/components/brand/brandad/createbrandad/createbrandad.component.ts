import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';
import swal from 'sweetalert';

@Component({
  selector: 'app-createbrandad',
  templateUrl: './createbrandad.component.html',
  styleUrls: ['./createbrandad.component.scss']
})
export class CreatebrandadComponent implements OnInit {

  public organisationid;
  public tag;
  public selecttag;
  public catagory;
  public selectcatagory;
  public campaign;
  public selectcampaign;

  public updatebrandad;
  public uploadimage;

  createbrandadsForm: FormGroup;
  submitted = false;
  @ViewChild('fileInput') fileInput: ElementRef;

  constructor(private _apiService: ApiService, private router: Router, private formBuilder: FormBuilder) { }


  ngOnInit() {
    const currentUser = JSON.parse(localStorage.getItem('currentuser'));
    this.organisationid = currentUser.organisation_id;

    this.gettag();
    this.getcategory();
    this.getcampaign();

    // add Brandads formgroup
    this.createbrandadsForm = this.formBuilder.group({
      // brand_id: ['', Validators.required],
      category_id: ['', Validators.required],
      campaign_id: ['', Validators.required],
      tag_id: ['', Validators.required],
      start_date: ['', Validators.required],
      end_date: ['', Validators.required],
      viewer_points: ['', Validators.required],
      ancestors_depth: ['', Validators.required],
      ancestors_points: ['', Validators.required],
      brand_ad_name: ['', Validators.required],
      brand_ad_des: ['', Validators.required],
    });

  }

  get f() { return this.createbrandadsForm.controls; }

  // get tag
  gettag() {
    this._apiService.listtag('true').subscribe(
      res => {
        this.tag = res;
        if (this.tag.statuscode == 200) {
          this.selecttag = this.tag.data;
        }
      },
      err => console.error(err)
    );
  }


  // get category

  getcategory() {
    this._apiService.listcategory('true').subscribe(
      res => {
        this.catagory = res;
        if (this.catagory.statuscode == 200) {
          this.selectcatagory = this.catagory.data;
        }
      },
      err => console.error(err)
    );
  }


  // get Campaign

  getcampaign() {
    this._apiService.listcampaign_on_brandid('true', this.organisationid).subscribe(
      res => {
        this.campaign = res;
        console.log('camp', this.campaign);
        if (this.campaign.statuscode == 200) {
          this.selectcampaign = this.campaign.data;
        }
      },
      err => console.error(err)
    );
  }

  // update store image

  fileChange(e) {
    const profiles = e.target.files[0];
    this.updatebrandad = profiles;
    const reader = new FileReader();
    reader.onload = () => {
      this.uploadimage = reader.result;
    };
    reader.readAsDataURL(profiles);
  }


  // create brand ads

  onSubmit() {
    this.submitted = true;
    if (this.createbrandadsForm.valid && this.updatebrandad) {
      const createBrandad: FormData = new FormData();
      const file: File = this.updatebrandad;
      createBrandad.append('brand_id', this.organisationid);
      createBrandad.append('category_id', this.createbrandadsForm.value.category_id);
      createBrandad.append('campaign_id', this.createbrandadsForm.value.campaign_id);
      createBrandad.append('tag_id', this.createbrandadsForm.value.tag_id);
      createBrandad.append('start_date', this.createbrandadsForm.value.start_date);
      createBrandad.append('end_date', this.createbrandadsForm.value.end_date);
      createBrandad.append('image', file);
      createBrandad.append('brand_ad_name', this.createbrandadsForm.value.brand_ad_name);
      createBrandad.append('brand_ad_des', this.createbrandadsForm.value.brand_ad_des);
      createBrandad.append('viewer_points', this.createbrandadsForm.value.viewer_points);
      createBrandad.append('ancestors_depth', this.createbrandadsForm.value.ancestors_depth);
      createBrandad.append('ancestors_points', this.createbrandadsForm.value.ancestors_points);

      this._apiService.createbrandads(createBrandad).subscribe((data: any) => {

        if (data.statuscode = 200) {
          this.router.navigate(['/brandad']);
          this.createbrandadsForm.reset();
          swal({
            text: "Brand ad Created Successfully.",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
         
        } else {
          swal({
            text: "Brand ad Creation Failed!",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        }
      });
    } else {
      swal({
        text: "Some fields are empty.",
        buttons: [false],
        dangerMode: true,
        timer: 3000
      });
    }
  }



}
