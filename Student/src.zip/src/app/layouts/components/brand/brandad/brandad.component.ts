import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';

import swal from 'sweetalert';

@Component({
  selector: 'app-brandad',
  templateUrl: './brandad.component.html',
  styleUrls: ['./brandad.component.scss']
})
export class BrandadComponent implements OnInit {

  display = 'none';
  show = 'none';

  public userid;
  public brandadsdetails;
  public brandads;

  public tag;
  public selecttag;
  public catagory;
  public selectcatagory;
  public campaign;
  public selectcampaign;

  editbrandadsForm: FormGroup;
  public updatebrandad;
  submitted = false;
  public uploadimage;

  // edit brandad
  public category_id;
  public campaign_id;
  public tag_id



  editform = false;
  table = true;

  // view
  public viewdetails = [];

  displayedColumns = ['sno','brand_ad_name', 'start_date','end_date', 'action'];
  dataSource: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private _apiService: ApiService, private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    const currentUser = JSON.parse(localStorage.getItem('currentuser'));
    this.userid = currentUser.organisation_id;

    this.getownbrandaddetail();
    this.gettag();
    this.getcategory();
    this.getcampaign();

    // update Brandads formgroup
    this.editbrandadsForm = this.formBuilder.group({
      brand_ad_id: ['', Validators.required],
      category_id: ['', Validators.required],
      campaign_id: ['', Validators.required],
      tag_id: ['', Validators.required],
      start_date: ['', Validators.required],
      end_date: ['', Validators.required],
      viewer_points: ['', Validators.required],
      ancestors_depth: ['', Validators.required],
      ancestors_points: ['', Validators.required],
      brand_ad_name: ['', Validators.required],
      brand_ad_des: ['', Validators.required],
    });

  }

  onCloseHandled() {
    this.editform = false;
    this.table = true;
  }

  get f() { return this.editbrandadsForm.controls; }

  // get tag
  gettag() {
    this._apiService.listtag('true').subscribe(
      res => {
        this.tag = res;
        if (this.tag.statuscode == 200) {
          this.selecttag = this.tag.data;
        }
      },
      err => console.error(err)
    );
  }


  // get category

  getcategory() {
    this._apiService.listcategory('true').subscribe(
      res => {
        this.catagory = res;
        if (this.catagory.statuscode == 200) {
          this.selectcatagory = this.catagory.data;
        }
      },
      err => console.error(err)
    );
  }


  // get Campaign

  getcampaign() {
    this._apiService.listcampaign_on_brandid('true', this.userid).subscribe(
      res => {
        this.campaign = res;
        if (this.campaign.statuscode == 200) {
          this.selectcampaign = this.campaign.data;
        }
      },
      err => console.error(err)
    );
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  getownbrandaddetail() {
    this._apiService.getownbrandads('', this.userid).subscribe(
      res => {
        this.brandadsdetails = res;
        if (this.brandadsdetails.statuscode == 200) {
          this.dataSource = new MatTableDataSource();
          this.dataSource.data = this.brandadsdetails.data;
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
        }
      },
      err => console.error(err)
    );
  }


  // update store image

  fileChange(e) {
    const profiles = e.target.files[0];
    this.updatebrandad = profiles;
    const reader = new FileReader();
    reader.onload = () => {
      this.uploadimage = reader.result;
    };
    reader.readAsDataURL(profiles);
  }



  editbrandaddetails(brandad) {
    this.brandads = brandad;
    this.table = false;
    this.editform = true;
    this.uploadimage = this.brandads.brand_ad_img;
    this.editbrandadsForm.setValue({
      brand_ad_id: this.brandads.brand_ad_id,
      category_id: this.brandads.category_id,
      campaign_id: this.brandads.campaign_id,
      tag_id: this.brandads.tag_id,
      start_date: this.brandads.start_date,
      end_date: this.brandads.end_date,
      viewer_points: this.brandads.viewer_points,
      ancestors_depth: this.brandads.ancestors_depth,
      ancestors_points: this.brandads.ancestors_points,
      brand_ad_name: this.brandads.brand_ad_name,
      brand_ad_des: this.brandads.brand_ad_des,
    });

  }


  // update brand ads

  onUpdate() {
    this.submitted = true;
    if (this.editbrandadsForm.valid) {
      const updateBrandad: FormData = new FormData();
      const file: File = this.updatebrandad;
      updateBrandad.append('brand_id', this.userid);
      updateBrandad.append('category_id', this.editbrandadsForm.value.category_id);
      updateBrandad.append('campaign_id', this.editbrandadsForm.value.campaign_id);
      updateBrandad.append('tag_id', this.editbrandadsForm.value.tag_id);
      updateBrandad.append('start_date', this.editbrandadsForm.value.start_date);
      updateBrandad.append('end_date', this.editbrandadsForm.value.end_date);
      updateBrandad.append('image', file);
      updateBrandad.append('brand_ad_id', this.editbrandadsForm.value.brand_ad_id);
      updateBrandad.append('brand_ad_name', this.editbrandadsForm.value.brand_ad_name);
      updateBrandad.append('brand_ad_des', this.editbrandadsForm.value.brand_ad_des);
      updateBrandad.append('viewer_points', this.editbrandadsForm.value.viewer_points);
      updateBrandad.append('ancestors_depth', this.editbrandadsForm.value.ancestors_depth);
      updateBrandad.append('ancestors_points', this.editbrandadsForm.value.ancestors_points);

      this._apiService.updatebrandads(updateBrandad).subscribe((data: any) => {
        this.getownbrandaddetail();   
        if (data.status == 200) {
          this.onCloseHandled();
          this.editbrandadsForm.reset();
          swal({
            text: "BrandAd Updated Successfully.",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        } else {
          swal({
            text: "Failed to Update BrandAd",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        }
      });
    } else {
      swal({
        text: "Some fields are empty.",
        buttons: [false],
        dangerMode: true,
        timer: 3000
      });
    }
  }



  // disable brand
  deletebrandads(brand_ad_id, is_active) {
    if (brand_ad_id && is_active) {
      if (is_active == 'true') {
        swal({
          text: "Are you sure?. Confirm to activate the brandad.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.brandadsdelete(brand_ad_id, is_active).subscribe((data: any) => {
                if (data.statuscode = 204) {
                  this.getownbrandaddetail();
                  swal({
                    text: "BrandAd Activation Successful.",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Activate BrandAd",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      } else {
        swal({
          text: "Are you sure?. Confirm to deactivate the brandad.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.brandadsdelete(brand_ad_id, is_active).subscribe((data: any) => {
                if (data.statuscode = 204) {
                  this.getownbrandaddetail();
                  swal({
                    text: "BrandAd Deactivated Successfully",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Deactivate BrandAd",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      }
    }
  }


  // view brand ad details

  onClickbrandaddetails(brand_ad_id) {
    localStorage.setItem('brandad_id', brand_ad_id);
    this.router.navigate(['/viewbrandad']);
  }

}
