import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatebrandadComponent } from './createbrandad.component';

describe('CreatebrandadComponent', () => {
  let component: CreatebrandadComponent;
  let fixture: ComponentFixture<CreatebrandadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatebrandadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatebrandadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
