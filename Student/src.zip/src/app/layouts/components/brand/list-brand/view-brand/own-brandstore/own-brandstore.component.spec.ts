import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OwnBrandstoreComponent } from './own-brandstore.component';

describe('OwnBrandstoreComponent', () => {
  let component: OwnBrandstoreComponent;
  let fixture: ComponentFixture<OwnBrandstoreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OwnBrandstoreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OwnBrandstoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
