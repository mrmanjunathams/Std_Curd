import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';
import swal from 'sweetalert';

@Component({
  selector: 'app-view-brand',
  templateUrl: './view-brand.component.html',
  styleUrls: ['./view-brand.component.scss']
})
export class ViewBrandComponent implements OnInit {

  public brandid;
  public brand;
  public branddetail;
  public usertype;


  constructor(private _apiService: ApiService, private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    const currentUser = JSON.parse(localStorage.getItem('currentuser'));
    this.usertype = currentUser.user_type;
    this.getstore();
  }

  // get own brand stores details

  getstore() {
    this.brandid = localStorage.getItem('brand_id');
    if (this.brandid) {
      this._apiService.getownbrand(this.brandid).subscribe(
        res => {
          this.brand = res;
          if (this.brand.statuscode == 200) {
            this.branddetail = this.brand.data;
            console.log('brandview', this.branddetail);
          }
        },
        err => console.error(err)
      );
    } else {
    }
  }

  // disable brand
  deletebrand(brand_id, is_active) {
    if (brand_id && is_active) {
      if (is_active == 2) {
        swal({
          text: "Are you sure?. Confirm to activate the brand.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.branddelete(brand_id, is_active).subscribe((data: any) => {
                this.getstore();
                if (data.statuscode = 204) {
                  swal({
                    text: "Brand Activated Successfully",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Activate Brand",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      } else {
        swal({
          text: "Are you sure?. Confirm to Deactivate the brand.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 9000
        })
          .then((value) => {
            if(value){
            this._apiService.branddelete(brand_id, is_active).subscribe((data: any) => {
              this.getstore();
              if (data.statuscode = 204) {
                swal({
                  text: "Brand Deactivated Successfully",
                  buttons: [false],
                  dangerMode: true,
                  timer: 3000
                });
              } else {
                swal({
                  text: "Failed to Deactivate Brand",
                  buttons: [false],
                  dangerMode: true,
                  timer: 3000
                });
              }
            });
          }
          });

      }
    }
  }
}