import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OwnBrandadsComponent } from './own-brandads.component';

describe('OwnBrandadsComponent', () => {
  let component: OwnBrandadsComponent;
  let fixture: ComponentFixture<OwnBrandadsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OwnBrandadsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OwnBrandadsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
