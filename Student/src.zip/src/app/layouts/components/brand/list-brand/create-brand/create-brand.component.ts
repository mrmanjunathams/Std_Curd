import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';

import swal from 'sweetalert';

@Component({
  selector: 'app-create-brand',
  templateUrl: './create-brand.component.html',
  styleUrls: ['./create-brand.component.scss']
})
export class CreateBrandComponent implements OnInit {


  public username;
  public updatebrandimage;
  public updatebrand;
  public userid;
  public usertype;

  createbrandForm: FormGroup;
  submitted = false;
  @ViewChild('fileInput') fileInput: ElementRef;

  constructor(private _apiService: ApiService, private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    const currentUser = JSON.parse(localStorage.getItem('currentuser'));
    this.username = currentUser.username;
    this.userid = currentUser.user_id;
    this.usertype = currentUser.user_type;
    // add category formgroup
    this.createbrandForm = this.formBuilder.group({
      organization_name: ['', Validators.required],
      organisation_gst: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      approved_by: [this.userid],
      user_type: ['brand'],
      mobile_number: ['', [Validators.required, Validators.pattern('[6-9]\\d{9}')]],
      username: ['', Validators.required]
    });
  }
 

  get f() { return this.createbrandForm.controls; }

  // update brand image

  // fileChange(e) {
  //   const profiles = e.target.files[0];
  //   this.updatebrand = profiles;
  //   if (profiles) {
  //     const reader = new FileReader();
  //     reader.onload = () => {
  //       this.updatebrandimage = reader.result;
  //     };
  //     reader.readAsDataURL(profiles);
  //   }
  // }

  // create brand

  onSubmit() {
    this.submitted = true;
    if (this.createbrandForm.valid) {
      // const createBrand: FormData = new FormData();
      // const file: File = this.updatebrand;
      // createBrand.append('brand_name', this.createbrandForm.value.brand_name);
      // createBrand.append('image', file);
      // createBrand.append('user_name', this.username);
      // createBrand.append('brand_gst', this.createbrandForm.value.brand_gst);
      // createBrand.append('email', this.createbrandForm.value.email);
      // createBrand.append('password', this.createbrandForm.value.password);

      this._apiService.createbrand(this.createbrandForm.value).subscribe((data: any) => {
        if (data.statuscode = 200) {
          this.createbrandForm.reset();
          this.router.navigate(['/listbrand']);
          swal({
            text: "Create Brand Successfully.",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        } else {
          swal({
            text: "Create Brand Falied.",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        }
      });
    } else {
      swal({
        text: "Some fields are empty.",
        buttons: [false],
        dangerMode: true,
        timer: 3000
      });
    }
  }

}
