import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';
import swal from 'sweetalert';

@Component({
  selector: 'app-list-brand',
  templateUrl: './list-brand.component.html',
  styleUrls: ['./list-brand.component.scss']
})

export class ListBrandComponent implements OnInit {

  // modal
  display = 'none';
  public brandedit;
  public updatebrand;
  public brand;
  displayedColumns = ['sno', 'brand_name', 'created_at', 'is_active'];
  dataSource: any;
  status = false;

  public updatebrandimage;

  // update
  editbrandForm: FormGroup;
  public username;
  public usertype;
  submitted = false;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private _apiService: ApiService, private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {

    this.getbrand();

    const currentUser = JSON.parse(localStorage.getItem('currentuser'));
    this.username = currentUser.username;
    this.usertype = currentUser.user_type;
    console.log(currentUser.user_type);

    // update category formgroup
    this.editbrandForm = this.formBuilder.group({
      brand_id: ['', Validators.required],
      brand_name: ['', Validators.required],
      brand_logo: [''],
      user_name: [this.username]
    });
  }

  get u() { return this.editbrandForm.controls; }

  // model service

  openModal() {
    this.display = 'block';
  }
  onCloseHandled() {
    this.display = 'none';
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  // get brand

  getbrand() {
    this._apiService.listbrand('').subscribe(
      res => {
        this.brand = res;       
        if (this.brand.statuscode == 200) {
          this.dataSource = new MatTableDataSource(); 
          this.dataSource.data = this.brand.data;
          this.dataSource.sort = this.sort;
          this.updatebrandimage = this.dataSource.data.brand_img;
          this.dataSource.paginator = this.paginator;
        }
      },
      err => console.error(err)
    );
  }

  // view own store

  onClickbrandownstore(brand_id) {
    if (brand_id) {
      localStorage.setItem('brand_id', brand_id);
      this.router.navigate(['/viewbrand'])
    }
  }

  // edit brand
  editbrand(brand) {
    this.brandedit = brand;
    this.editbrandForm.setValue({
      brand_id: this.brandedit.brand_id,
      brand_name: this.brandedit.brand_name,
      image: this.brandedit.brand_img,
      user_name: this.username
    });
  }

  // update brand image
  fileChange(e) {
    const profiles = e.target.files[0];
    this.updatebrand = profiles.name;
    if (profiles) {
      const reader = new FileReader();
      reader.onload = () => {
        this.updatebrandimage = reader.result;
      };
      reader.readAsDataURL(profiles);
    } else {
      this.updatebrandimage = this.editbrandForm.value.brand_logo;
    }
  }

  // update brand
  onUpdate() {
    this.submitted = true;
    if (this.editbrandForm.valid) {
      const updateBrand: FormData = new FormData();
      updateBrand.append('brand_id', this.editbrandForm.value.brand_id);
      updateBrand.append('brand_name', this.editbrandForm.value.brand_name);
      updateBrand.append('brand_logo', this.updatebrand);
      updateBrand.append('user_name', this.username);
      this._apiService.brandupdate(updateBrand).subscribe((data: any) => {
        this.getbrand();
        this.onCloseHandled();
        if (data.statuscode = 200) {
          swal({
            text: "Brand Updated Successfully",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        } else {
          swal({
            text: "Failed to Update Brand",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        }
      });
    }
  }

  // disable brand

  deletebrand(brand_id, is_active) {
    if (brand_id && is_active) {
      if (is_active == 2) {
        swal({
          text: "Are you sure?. Confirm to activate the brand.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.branddelete(brand_id, is_active).subscribe((data: any) => {
                if (data.statuscode = 204) {
                  this.getbrand();
                  swal({
                    text: "Brand Activated Successfully",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Activate Brand",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      } else {
        swal({
          text: "Are you sure?. Confirm to deactivate the brand.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.branddelete(brand_id, is_active).subscribe((data: any) => {
                if (data.statuscode = 204) {
                  this.getbrand();
                  swal({
                    text: "Brand Deactivated Successfully",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Deactivate Brand",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      }
    }
  }
}
