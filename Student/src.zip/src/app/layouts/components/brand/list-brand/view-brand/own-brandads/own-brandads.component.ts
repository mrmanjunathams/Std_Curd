import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';

import swal from 'sweetalert';

@Component({
  selector: 'app-own-brandads',
  templateUrl: './own-brandads.component.html',
  styleUrls: ['./own-brandads.component.scss']
})
export class OwnBrandadsComponent implements OnInit {

  public brandid;
  public brandadsdetails;
  public usertype;

  displayedColumns = ['sno', 'brand_ad_name', 'action'];
  dataSource: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private _apiService: ApiService, private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    const currentUser = JSON.parse(localStorage.getItem('currentuser'));
    this.usertype = currentUser.user_type;
    this.brandid = localStorage.getItem('brand_id');
    this.getownbrandaddetail();
  }

  getownbrandaddetail() {
    if (this.brandid) {
      this._apiService.getownbrandads('', this.brandid).subscribe(
        res => {
          this.brandadsdetails = res;
          if (this.brandadsdetails.statuscode == 200) {
            this.dataSource = new MatTableDataSource();
            this.dataSource.data = this.brandadsdetails.data;
            this.dataSource.sort = this.sort;
            this.dataSource.paginator = this.paginator;
          }
        },
        err => console.error(err)
      );
    }
    else {
    }
  }

  // view brand ad details

  onClickbrandaddetails(brand_ad_id) {
    localStorage.setItem('brandad_id', brand_ad_id);
    this.router.navigate(['/viewbrandad']);
  }


  // disable brand
  deletebrandads(brand_ad_id, is_active) {
    if (brand_ad_id && is_active) {
      if (is_active == 'true') {
        swal({
          text: "Are you sure?. Confirm to activate the brandad.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.brandadsdelete(brand_ad_id, is_active).subscribe((data: any) => {
                if (data.statuscode = 204) {
                  this.getownbrandaddetail();
                  swal({
                    text: "BrandAd Activated Successfully",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: " Failed to Activate BrandAd",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      } else {
        swal({
          text: "Are you sure?. Confirm to deactivate the brandad.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.brandadsdelete(brand_ad_id, is_active).subscribe((data: any) => {
                if (data.statuscode = 204) {
                  this.getownbrandaddetail();
                  swal({
                    text: "BrandAd Deactivated Successfully",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Deactivate BrandAd",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      }
    }
  }

}
