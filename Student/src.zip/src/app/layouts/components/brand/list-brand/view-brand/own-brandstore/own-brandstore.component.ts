import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';
import swal from 'sweetalert';

@Component({
  selector: 'app-own-brandstore',
  templateUrl: './own-brandstore.component.html',
  styleUrls: ['./own-brandstore.component.scss']
})
export class OwnBrandstoreComponent implements OnInit {

  public brandid;
  public brandstoredetails;
  public usertype;

  displayedColumns = ['sno', 'store_name', 'store_email', 'action'];
  dataSource: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private _apiService: ApiService, private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    const currentUser = JSON.parse(localStorage.getItem('currentuser'));
    this.usertype = currentUser.user_type;
    this.brandid = localStorage.getItem('brand_id');
    this.getstoredetail();
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  getstoredetail() {
    if (this.brandid) {
      this._apiService.listbrandstores('', this.brandid).subscribe(
        res => {
          this.brandstoredetails = res;
          if (this.brandstoredetails.statuscode == 200) {
            this.dataSource = new MatTableDataSource();
            this.dataSource.data = this.brandstoredetails.data;
            this.dataSource.sort = this.sort;
            this.dataSource.paginator = this.paginator;
          }
        },
        err => console.error(err)
      );
    }
    else {
    }
  }

  // disable store
  deletestore(store_id, is_active) {
    if (store_id && is_active) {
      if (is_active == 2) {
        swal({
          text: "Are you sure?. Confirm to activate the store.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.storedelete(store_id, is_active).subscribe((data: any) => {
                this.getstoredetail();
                if (data.statuscode = 204) {
                  swal({
                    text: "Store Activated Successfully.",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Activate Store.",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      } else {
        swal({
          text: "Are you sure?. Confirm to deactivate the store.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.storedelete(store_id, is_active).subscribe((data: any) => {
                this.getstoredetail();
                if (data.statuscode = 204) {
                  swal({
                    text: "Store Deactivated Successfully.",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Deactivate Store.",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });

      }
    }
  }

  // view own store detail

  onClickownstoredetails(store_id) {
    if (store_id) {
      localStorage.setItem('store_id', store_id);
      this.router.navigate(['/viewstoredetail'])
    }
  }

}
