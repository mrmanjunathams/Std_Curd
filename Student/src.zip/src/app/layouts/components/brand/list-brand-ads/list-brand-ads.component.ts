import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';
import swal from 'sweetalert';
@Component({
  selector: 'app-list-brand-ads',
  templateUrl: './list-brand-ads.component.html',
  styleUrls: ['./list-brand-ads.component.scss']
})
export class ListBrandAdsComponent implements OnInit {

  public brandads;
  public usertype;
  
  displayedColumns = ['sno', 'brand_ad_name','created_at','start_date','end_date', 'action'];
  dataSource: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private _apiService: ApiService, private router: Router) { }

  ngOnInit() {

    const currentUser = JSON.parse(localStorage.getItem('currentuser'));
    this.usertype = currentUser.user_type;
    this.getbrandads();
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  // get brand ads
  getbrandads() {
    this._apiService.listbrandads('').subscribe(
      res => {
        this.brandads = res;
        if (this.brandads.statuscode == 200) {
          this.dataSource = new MatTableDataSource();
          this.dataSource.data = this.brandads.data;
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
        }
      },
      err => console.error(err)
    );
  }

  // disable brand
  deletebrandads(brand_ad_id, is_active) {
    if (brand_ad_id && is_active) {
      if (is_active == 'true') {
        swal({
          text: "Are you sure?. Confirm to activate the brandad.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.brandadsdelete(brand_ad_id, is_active).subscribe((data: any) => {
                if (data.statuscode = 204) {
                  this.getbrandads();
                  swal({
                    text: "BrandAd Activated Successfully",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Activate BrandAd",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      } else {
        swal({
          text: "Are you sure?. Confirm to deactivate the brandad.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.brandadsdelete(brand_ad_id, is_active).subscribe((data: any) => {
                if (data.statuscode = 204) {
                  this.getbrandads();
                  swal({
                    text: "BrandAd Deactivated Successfully",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Deactivate BrandAd",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      }
    }
  }

  // view brand ad details

  onClickbrandaddetails(brand_ad_id) {
    localStorage.setItem('brandad_id', brand_ad_id);
    this.router.navigate(['/viewbrandad']);
  }

}
