import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListBrandAdsComponent } from './list-brand-ads.component';

describe('ListBrandAdsComponent', () => {
  let component: ListBrandAdsComponent;
  let fixture: ComponentFixture<ListBrandAdsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListBrandAdsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListBrandAdsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
