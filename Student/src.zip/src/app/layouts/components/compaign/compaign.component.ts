import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { Observable, of } from 'rxjs';
// import { DatePipe } from '@angular/common';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import swal from 'sweetalert';

@Component({
  selector: 'app-compaign',
  templateUrl: './compaign.component.html',
  styleUrls: ['./compaign.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', display: 'none' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class CompaignComponent implements OnInit {

  public listcampaign;
  public current_user;
  public campaign;
  public usertype;

  // modal
  display = 'none';
  tooltipform = false;

  //update
  editcampaignForm: FormGroup;

  //add
  addcampaignForm: FormGroup;
  submitted = false;

  displayedColumns = ['sno', 'campaign_name', 'start_date','end_date', 'action'];
  dataSource: any;
  isExpansionDetailRow = (i: number, row: Object) => row.hasOwnProperty('detailRow');
  expandedElement: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  constructor(private _apiService: ApiService, private router: Router, private formBuilder: FormBuilder,) { }

  ngOnInit() {
    this.current_user = JSON.parse(localStorage.getItem("currentuser"));
    this.usertype = this.current_user.user_type;
    this.getcampaign();

    this.addcampaignForm = this.formBuilder.group({
      is_active: ['true'],
      campaign_name: ['', Validators.required],
      start_date: ['', Validators.required],
      end_date: ['', Validators.required],
      brand_id: [],
      store_id: []
    });

    // update category formgroup
    this.editcampaignForm = this.formBuilder.group({
      campaign_id: ['', Validators.required],
      campaign_name: ['', Validators.required],
      start_date: ['', Validators.required],
      end_date: ['', Validators.required],
    });
  }

  get f() { return this.addcampaignForm.controls; }
  get u() { return this.editcampaignForm.controls; }

  // tag add form

  onclicktooltip() {
    this.tooltipform = true;
  }

  cancel() {
    this.tooltipform = false;
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  openModal() {
    this.display = 'block';
  }
  onCloseHandled() {
    this.display = 'none';
  }
  // get brand ads
  getcampaign() {
    if (this.current_user.user_type == 'brand_admin' || this.current_user.user_type == 'brand_user') {
      this._apiService.listcampaign_on_brandid("", this.current_user.organisation_id).subscribe(
        res => {
          this.listcampaign = res;
          if (this.listcampaign.statuscode == 200) {
            this.dataSource = new MatTableDataSource();
            this.dataSource.data = this.listcampaign.data;
            this.dataSource.sort = this.sort;
            this.dataSource.paginator = this.paginator;
          }
        },
        err => console.error(err),
      );
    }
    else if (this.current_user.user_type == 'store_user' || this.current_user.user_type == 'store_admin') {
      this._apiService.listcampaign_on_storeid("", this.current_user.organisation_id).subscribe(
        res => {
          this.listcampaign = res;
          if (this.listcampaign.statuscode == 200) {
            this.dataSource = new MatTableDataSource();
            this.dataSource.data = this.listcampaign.data;
            this.dataSource.sort = this.sort;
            this.dataSource.paginator = this.paginator;
          }
        },
        err => console.error(err)
      );
    }
    else {
      this._apiService.listcampaign('').subscribe(
        res => {
          this.listcampaign = res;
          if (this.listcampaign.statuscode == 200) {
            this.dataSource = new MatTableDataSource();
            this.dataSource.data = this.listcampaign.data;
            this.dataSource.sort = this.sort;
            this.dataSource.paginator = this.paginator;
          }
        },
        err => console.error(err)
      );
    }
  }

  // active and deactive
  delete(campaign_id, is_active) {
    if (campaign_id && is_active) {
      if (is_active == 'true') {
        swal({
          text: "Are you sure?. Confirm to activate the Campaign.", buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.campaigndisable(campaign_id, is_active).subscribe((data: any) => {
                this.getcampaign();
                if (data.statuscode = 204) {
                  swal({
                    text: "Campaign Activated Successfully.",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Activate Campaign",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      } else {
        swal({
          text: "Are you sure?. Confirm to deactivate the Campaign.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.campaigndisable(campaign_id, is_active).subscribe((data: any) => {
                this.getcampaign();
                if (data.statuscode = 204) {
                  swal({
                    text: "Campaign Deactivated Successfully.",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Deactivate Campaign",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      }
    }
  }

  //adding campaign
  onSubmit() {
    if (this.current_user.user_type == 'brand_admin' || this.current_user.user_type == 'brand_user') {
      this.addcampaignForm.value.brand_id = this.current_user.organisation_id;
    }
    else {
      this.addcampaignForm.value.store_id = this.current_user.organisation_id;
    }
    this.submitted = true;
    if (this.addcampaignForm.valid) {
      this._apiService.campaignadd(this.addcampaignForm.value).subscribe((data: any) => {
        this.cancel();
        if (data.statuscode == 200) {
          this.getcampaign();
          this.addcampaignForm.reset();
          swal({
            text: "Campaign Created Successfully.",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        } else {
          swal({
            text: "Failed to Create Campaign",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        }
      });
    }
  }

  // edit category

  editcategory(campaign) {
    this.campaign = campaign;
    this.editcampaignForm.setValue({
      campaign_name: this.campaign.campaign_name,
      campaign_id: this.campaign.campaign_id,
      start_date: this.campaign.start_date, 
      end_date: this.campaign.end_date
      // start_date: this.datePipe.transform(this.campaign.start_date, 'dd-mm-yyyy'),
      // end_date:  this.datePipe.transform(this.campaign.end_date, 'dd-mm-yyyy'),
    });
  }

  // update campaign
  onUpdate() {
    if (this.editcampaignForm.valid) {
      this._apiService.campaignupdate(this.editcampaignForm.value).subscribe((data: any) => {
        this.getcampaign();
        this.onCloseHandled();
        if (data.statuscode == 200) {
          swal({
            text: "Campaign Updated Successfully",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        } else {
          swal({
            text: "Failed to Update Campaign",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        }
      });
    }

  }
}
