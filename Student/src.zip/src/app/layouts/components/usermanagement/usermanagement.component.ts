import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';
import swal from 'sweetalert';

@Component({
  selector: 'app-usermanagement',
  templateUrl: './usermanagement.component.html',
  styleUrls: ['./usermanagement.component.scss']
})
export class UsermanagementComponent implements OnInit {

 
  public userid;
  public tag;
  public selecttag;
  public catagory;
  public selectcatagory;
  public campaign;
  public selectcampaign;

  public updatebrandad;
  public uploadimage;


  AdminUserManagementComponent: FormGroup;
  submitted = false;

  displayedColumns = ['sno', 'username', 'email', 'mobile_number', 'action'];
  dataSource: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  public usertype;
  public user;
  public organisation;

  constructor(private _apiService: ApiService, private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    const currentUser = JSON.parse(localStorage.getItem('currentuser'));
    this.userid = currentUser.user_id;
    this.organisation = currentUser.organisation_id;
    this.usertype = currentUser.user_type;
    this.getadminuser();
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  
  // get super admins
  getadminuser() {
    this._apiService.listadminuser('',this.organisation).subscribe(
      res => {
        this.user = res;
        if (this.user.statuscode == 200) {
          this.dataSource = new MatTableDataSource();
          this.dataSource.data = this.user.data;
          console.log('users', this.dataSource.data);
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
        }
      },
      err => console.error(err)
    );
  }


  // active and deactive

  delete(user_id, is_active) {
    if (user_id && is_active) {
      if (is_active == 2) {
        swal({
          text: "Are you sure?. Confirm to activate the User.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.userdelete(user_id, is_active).subscribe((data: any) => {
                this.getadminuser();
                if (data.statuscode = 204) {
                  swal({
                    text: "User Activated Successfully",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Activate User",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      } else {
        swal({
          text: "Are you sure?. Confirm to deactivate the User.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.userdelete(user_id, is_active).subscribe((data: any) => {
                this.getadminuser();
                if (data.statuscode = 204) {
                  swal({
                    text: "User Deactivated Successfully",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Deactivate User",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      }
    }
  }

}
