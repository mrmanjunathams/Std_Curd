import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import swal from 'sweetalert';

@Component({
  selector: 'app-createuser',
  templateUrl: './createuser.component.html',
  styleUrls: ['./createuser.component.scss']
})
export class CreateuserComponent implements OnInit {
  public adminid;
  createadminForm: FormGroup;
  submitted = false;
  constructor(private formBuilder: FormBuilder, private _apiService: ApiService, private router: Router) { }

  ngOnInit() {
    const currentUser = JSON.parse(localStorage.getItem('currentuser'));
    this.adminid = currentUser.user_id;

    this.createadminForm = this.formBuilder.group({
      user_id: [this.adminid],
      approved_by: [this.adminid],
      username: ['', Validators.required],
      organization_name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      mobile_number: ['', [Validators.required, Validators.pattern('[6-9]\\d{9}')]],
    });

  }

  get f() { return this.createadminForm.controls; }

  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.createadminForm.valid) {
      this._apiService.createadmin(this.createadminForm.value).subscribe((data: any) => {
        if (data.statuscode == 200) {
          this.router.navigate(['/users']);
          this.createadminForm.reset();
          swal({
            text: "User Created Successfully",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        } else if (data.statuscode == 203) {
          swal({
            text: "User already exist.",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        } else {
          swal({
            text: "Failed to Create User",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        }
      },
        (err: HttpErrorResponse) => {

        });
    }
  }

}
