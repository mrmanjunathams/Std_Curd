import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';
import swal from 'sweetalert';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {

  public user;
  displayedColumns = ['sno', 'username', 'email', 'organization_name', 'user_type', 'action'];
  dataSource: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private _apiService: ApiService, private router: Router) { }

  ngOnInit() {
    this.getuser();
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  // get brand ads
  getuser() {
    this._apiService.listuser('').subscribe(
      res => {
        this.user = res;
        if (this.user.statuscode == 200) {
          this.dataSource = new MatTableDataSource();
          this.dataSource.data = this.user.data;
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
        }
      },
      err => console.error(err)
    );
  }

  // approval api

  approve(user_id, is_active) {
    if (user_id && is_active) {
      if (is_active == 2) {
      this._apiService.userapproval(user_id, is_active).subscribe((data: any) => {
        this.getuser();
        if (data.statuscode = 204) {
          swal({
            text: "User Approved Successfully",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        } else {
          swal({
            text: "Failed to Approve User",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        }
      });
    } else {
      this._apiService.userapproval(user_id, is_active).subscribe((data: any) => {
        this.getuser();
        if (data.statuscode = 204) {
          swal({
            text: "User Rejected Successfully",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        } else {
          swal({
            text: "Failed to Reject the User",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        }
      });
    }
    }
  }

  // active and deactive

  delete(user_id, is_active) {
    if (user_id && is_active) {
      if (is_active == 2) {
        swal({
          text: "Are you sure?. Confirm to activate the User.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.userdelete(user_id, is_active).subscribe((data: any) => {
                this.getuser();
                if (data.statuscode = 204) {
                  swal({
                    text: "User Activated Successfully",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Activate User",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      } else {
        swal({
          text: "Are you sure?. Confirm to deactivate the User.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.userdelete(user_id, is_active).subscribe((data: any) => {
                this.getuser();
                if (data.statuscode = 204) {
                  swal({
                    text: "User Deactivated Successfully",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Deactivate User",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      }
    }
  }
}
