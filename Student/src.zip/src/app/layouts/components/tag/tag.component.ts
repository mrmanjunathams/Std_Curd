import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';
import swal from 'sweetalert';
@Component({
  selector: 'app-tag',
  templateUrl: './tag.component.html',
  styleUrls: ['./tag.component.scss']
})
export class TagComponent implements OnInit {

  // modal
  display = 'none';

  public tag;
  public userid;
  tagform = false;

  // datatable
  displayedColumns = ['sno', 'tag_name', 'created_at', 'action'];
  dataSource: any;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  // add formGroup
  addtagForm: FormGroup;
  submitted = false;

  // update 

  public tags;
  edittagForm: FormGroup;
  public is_active;
  constructor(private _apiService: ApiService, private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.gettag();
    const currentUser = JSON.parse(localStorage.getItem('currentuser'));
    this.userid = currentUser.organisation_id;

    // add tag formgroup
    this.addtagForm = this.formBuilder.group({
      brand_id: [this.userid],
      tag_name: ['', Validators.required],
    });

    // update tag formgroup
    this.edittagForm = this.formBuilder.group({
      tag_id: ['', Validators.required],
      tag_name: ['', Validators.required],
    });
  }

  get f() { return this.addtagForm.controls; }
  get u() { return this.edittagForm.controls; }


  // tag add form

  onclicktag() {
    this.tagform = true;
  }

  cancel() {
    this.tagform = false;
  }

  // model service
  openModal() {
    this.display = 'block';
  }
  onCloseHandled() {
    this.display = 'none';
  }

  // table filter
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  // get tag
  gettag() {
    this._apiService.listtag('').subscribe(
      res => {
        this.tag = res;
        if (this.tag.statuscode == 200) {
          this.dataSource = new MatTableDataSource();
          this.dataSource.data = this.tag.data;
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
        }
      },
      err => console.error(err)
    );
  }

  // add tag

  onSubmit() {
    this.submitted = true;
    if (this.addtagForm.valid) {
      this._apiService.tagadd(this.addtagForm.value).subscribe((data: any) => {
        this.gettag();
        this.tagform = false;
        if (data.statuscode == 200) {
          this.addtagForm.reset();
          swal({
            text: "Tag Created Successfully",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        } else {
          swal({
            text: "Failed to Create Tag",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        }
      });
    }
  }

  // edit tag

  edittag(tag) {
    this.tags = tag;
    this.edittagForm.setValue({
      tag_name: this.tags.tag_name,
      tag_id: this.tags.tag_id
    });
  }

  // update tag
  onUpdate() {
    if (this.edittagForm.valid) {
      this._apiService.tagupdate(this.edittagForm.value).subscribe((data: any) => {
        this.gettag();
        this.onCloseHandled();
        if (data.statuscode == 200) {
          swal({
            text: "Tag Updated Successfully",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        } else {
          swal({
            text: "Failed to Update Tag",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        }
      });
    }
  }

  // disable tag

  deletetag(tag_id, is_active) {
    if (tag_id && is_active) {
      if (is_active == 'true') {
        swal({
          text: "Are you sure?. Confirm to activate the tag.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true
        })
          .then((value) => {
            if (value) {
              this._apiService.tagdisable(tag_id, is_active).subscribe((data: any) => {
                if (data.statuscode = 204) {
                  this.gettag();
                  swal({
                    text: "Tag Activated Successfully.",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });

                } else {
                  swal({
                    text: "Failed to Activate Tag",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
        } else {
          swal({
            text: "Are you sure?. Confirm to Deactivate the tag.",
            buttons: ['Cancel', 'Ok'],
            dangerMode: true
          })
            .then((value) => {
              if (value) {
                this._apiService.tagdisable(tag_id, is_active).subscribe((data: any) => {
                  if (data.statuscode = 204) {
                    this.gettag();
                    swal({
                      text: "Tag Deactivated Successfully.",
                      buttons: [false],
                      dangerMode: true,
                      timer: 3000
                    });
  
                  } else {
                    swal({
                      text: "Failed to Deactivate Tag",
                      buttons: [false],
                      dangerMode: true,
                      timer: 3000
                    });
                  }
                });
              }
            });
        }
      }
    }


  }
