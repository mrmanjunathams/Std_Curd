import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { Observable, of } from 'rxjs';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';

import swal from 'sweetalert';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', display: 'none' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class CustomerComponent implements OnInit {

  public listcustomer;
  displayedColumns = ['sno', 'name', 'email', 'mobile_number', 'action'];
  dataSource: any;
  isExpansionDetailRow = (i: number, row: Object) => row.hasOwnProperty('detailRow');
  expandedElement: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private _apiService: ApiService, private router: Router) { }

  ngOnInit() {
    this.getcustomer();
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  // get brand ads
  getcustomer() {
    this._apiService.listcustomer('').subscribe(
      res => {
        this.listcustomer = res;
        if (this.listcustomer.statuscode == 200) {
          this.dataSource = new MatTableDataSource();
          this.dataSource.data = this.listcustomer.data;
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
        }
      },
      err => console.error(err)
    );
  }

  // active and deactive

  delete(customer_id, is_active) {
    if (customer_id && is_active) {
      if (is_active == 2) {
        swal({
          text: "Are you sure?. Confirm to activate the Customer.",
          buttons: ['Cancel' , 'Ok'],
          dangerMode: true,
          timer:4000
        })
        .then((willDelete) => {
            if (willDelete) {
              this._apiService.customerdisable(customer_id, is_active).subscribe((data: any) => {
                this.getcustomer();
                if (data.statuscode = 204) {
                  swal({
                    text: "Customer Activated Successfully",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: " Failed to Activate Customer",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      } else {
        swal({
          text: "Are you sure?. Confirm to deactivate the Customer.",
          buttons: ['Cancel' , 'Ok'],
          dangerMode: true,
          timer:4000
        })
        .then((willDelete) => {
            if (willDelete) {
              this._apiService.customerdisable(customer_id, is_active).subscribe((data: any) => {
                this.getcustomer();
                if (data.statuscode = 204) {
                  swal({
                    text: "Customer Deactivated Successfully",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Deactivate Customer",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      }
    }
  }

}
