import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';
import swal from 'sweetalert';

@Component({
  selector: 'app-list-own-popads',
  templateUrl: './list-own-popads.component.html',
  styleUrls: ['./list-own-popads.component.scss']
})
export class ListOwnPopadsComponent implements OnInit {

  displayedColumns = ['sno', 'store_ad_name', 'store_offer'];
  dataSource: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  constructor(private _apiService: ApiService, private router: Router) { }

  ngOnInit() {
    
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

}
