import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListOwnPopadsComponent } from './list-own-popads.component';

describe('ListOwnPopadsComponent', () => {
  let component: ListOwnPopadsComponent;
  let fixture: ComponentFixture<ListOwnPopadsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListOwnPopadsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListOwnPopadsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
