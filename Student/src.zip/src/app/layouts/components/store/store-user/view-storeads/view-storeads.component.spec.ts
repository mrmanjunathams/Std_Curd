import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewStoreadsComponent } from './view-storeads.component';

describe('ViewStoreadsComponent', () => {
  let component: ViewStoreadsComponent;
  let fixture: ComponentFixture<ViewStoreadsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewStoreadsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewStoreadsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
