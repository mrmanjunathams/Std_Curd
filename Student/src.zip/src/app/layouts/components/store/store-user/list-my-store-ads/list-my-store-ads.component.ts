import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';
import swal from 'sweetalert';

@Component({
  selector: 'app-list-my-store-ads',
  templateUrl: './list-my-store-ads.component.html',
  styleUrls: ['./list-my-store-ads.component.scss']
})
export class ListMyStoreAdsComponent implements OnInit {
  // modal
  display = 'none';

  // edit
  public editstoread;
  updatestoreadForm: FormGroup;
  public uploadimage;
  public createad;
  public category;
  public selectcategory;
  public campaign;
  public selectcampaign;

  submitted = false;

  editform = false;
  table = true;

  public storead;
  public userid;
  public storeads;
  public currentUser;
  public storeaddetail;
  displayedColumns = ['sno',  'store_ad_name', 'start_date', 'end_date', 'store_offer', 'action', 'popads'];
  dataSource: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private _apiService: ApiService, private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.currentUser = JSON.parse(localStorage.getItem('currentuser'));
    this.userid = this.currentUser.organisation_id;

    this.getstoreads();
    this.getcategory();
    this.getcampaign();

    this.updatestoreadForm = this.formBuilder.group({
      store_ad_id: ['', Validators.required],
      category_id: ['', Validators.required],
      campaign_id: ['', Validators.required],
      store_offer: ['', Validators.required],
      start_date: ['', Validators.required],
      end_date: ['', Validators.required],
      pop_ad: ['', Validators.required],
      store_ad_name: ['', Validators.required],
      store_ad_des: ['', Validators.required],
      viewer_points: ['', Validators.required],
      ancestors_depth: ['', Validators.required],
      ancestors_points: ['', Validators.required],
    });
  }

  get f() { return this.updatestoreadForm.controls; }


  onCloseHandled() {
    this.editform = false;
    this.table = true;
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  // view storead storead_id

  getstoread(store_ad_id) {
    localStorage.setItem('storead_id',store_ad_id);
    this.router.navigate(['/viewstoread']);
  }


  // get own store ads
  getstoreads() {
    this._apiService.getownstoreads('', this.userid).subscribe(
      res => {
        this.storeads = res;
        if (this.storeads.statuscode == 200) {
          this.dataSource = new MatTableDataSource();
          this.dataSource.data = this.storeads.data;
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
        }
      },
      err => console.error(err)
    );
  }


  // get category
  getcategory() {
    this._apiService.listcategory('true').subscribe(
      res => {
        this.category = res;
        if (this.category.statuscode == 200) {
          this.selectcategory = this.category.data;
        }
      },
      err => console.error(err)
    );
  }

  // get campaign
  getcampaign() {
    this._apiService.listcampaign('true').subscribe(
      res => {
        this.campaign = res;
        if (this.campaign.statuscode == 200) {
          this.selectcampaign = this.campaign.data;
        }
      },
      err => console.error(err)
    );
  }

  // update store image

  fileChange(e) {
    const image = e.target.files[0];
    this.createad = image;
    if (image) {
      const reader = new FileReader();
      reader.onload = () => {
        this.uploadimage = reader.result;
      };
      reader.readAsDataURL(image);
    } else {

    }
  }


  // edit storeads

  onClickupdatestoread(storeads) {
    this.editstoread = storeads;
    this.table = false;
    this.editform = true;
    this.uploadimage = this.editstoread.store_ad_img;
    this.updatestoreadForm.setValue({
      store_ad_id: this.editstoread.store_ad_id,
      category_id: this.editstoread.category_id,
      campaign_id: this.editstoread.campaign_id,
      store_offer: this.editstoread.store_offer,
      start_date: this.editstoread.start_date,
      end_date: this.editstoread.end_date,
      pop_ad: this.editstoread.pop_ad,
      store_ad_name: this.editstoread.store_ad_name,
      store_ad_des: this.editstoread.store_ad_des,
      viewer_points: this.editstoread.viewer_points,
      ancestors_depth: this.editstoread.ancestors_depth,
      ancestors_points: this.editstoread.ancestors_points,
    });
  }


  // create store ad

  onSubmit() {
    this.submitted = true;
    if (this.updatestoreadForm.valid) {
      const file: File = this.createad;
      const updateStoread: FormData = new FormData();
      updateStoread.append('store_ad_id', this.updatestoreadForm.value.store_ad_id);
      updateStoread.append('category_id', this.updatestoreadForm.value.category_id);
      updateStoread.append('campaign_id', this.updatestoreadForm.value.campaign_id);
      updateStoread.append('store_offer', this.updatestoreadForm.value.store_offer);
      updateStoread.append('start_date', this.updatestoreadForm.value.start_date);
      updateStoread.append('end_date', this.updatestoreadForm.value.end_date);
      updateStoread.append('pop_ad', this.updatestoreadForm.value.pop_ad);
      updateStoread.append('image', file);
      updateStoread.append('store_ad_name', this.updatestoreadForm.value.store_ad_name);
      updateStoread.append('store_ad_des', this.updatestoreadForm.value.store_ad_des);
      updateStoread.append('viewer_points', this.updatestoreadForm.value.viewer_points);
      updateStoread.append('ancestors_depth', this.updatestoreadForm.value.ancestors_depth);
      updateStoread.append('ancestors_points', this.updatestoreadForm.value.ancestors_points);

      this._apiService.updatestoread(updateStoread).subscribe((data: any) => {
        if (data.statuscode = 200) {
          this.getstoreads();
          this.editform = false;
          this.table = true;
          swal({
            text: "StoreAd Updated Successfully",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        } else {
          swal({
            text: "Failed to Update StoreAd",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        }
      });
    } else {
      swal({
        text: "Some fields are empty.",
        buttons: [false],
        dangerMode: true,
        timer: 3000
      });
    }
  }

  // disable storeads
  deletestoreads(store_ad_id, is_active) {
    if (store_ad_id && is_active) {
      if (is_active == 'true') {
        swal({
          text: "Are you sure?. Confirm to activate the storead.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.storeadsdelete(store_ad_id, is_active).subscribe((data: any) => {
                this.getstoreads();
                if (data.statuscode = 204) {
                  swal({
                    text: "StoreAd Activated Successfully",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Activate StoreAd",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      } else {
        swal({
          text: "Are you sure?. Confirm to deactivate the storead.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.storeadsdelete(store_ad_id, is_active).subscribe((data: any) => {
                this.getstoreads();
                if (data.statuscode = 204) {
                  swal({
                    text: "StoreAd Deactivated Successfully",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Deactivate StoreAd",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      }
    }
  }

  deletepopads(store_ad_id, pop_ad) {
    if (store_ad_id && pop_ad) {
      if (pop_ad == 'true') {
        swal({
          text: "Are you sure?. Confirm to Make the popad.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.popadsdelete(store_ad_id, pop_ad).subscribe((data: any) => {
                this.getstoreads();
                if (data.statuscode == 200) {
                  swal({
                    text: " PopAd added Successfully.",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: " PopAd Failed!.",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      } else {
        swal({
          text: "Are you sure?. Confirm to Remove the Popad.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.popadsdelete(store_ad_id, pop_ad).subscribe((data: any) => {
                this.getstoreads();
                if (data.statuscode == 200) {
                  swal({
                    text: "PopAd removed successfully",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "PopAd Failed!",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      }
    }
  }

}
