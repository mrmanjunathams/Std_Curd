import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-storeads',
  templateUrl: './view-storeads.component.html',
  styleUrls: ['./view-storeads.component.scss']
})
export class ViewStoreadsComponent implements OnInit {

  public store_ad_id;
  public storeads;
  public viewstoreads;
  public usertype;

  constructor(private _apiService: ApiService, private router: Router) { }

  ngOnInit() {
    const currentUser = JSON.parse(localStorage.getItem('currentuser'));
    this.usertype = currentUser.user_type;
    this.store_ad_id = localStorage.getItem('storead_id')
    this.getstoread();
  }

  // get viewstoread

  getstoread() {
    this._apiService. getstoread(this.store_ad_id).subscribe(
      res => {
        this.storeads = res;
        if (this.storeads.statuscode == 200) {
          this.viewstoreads = this.storeads.data;
        }
      },
      err => console.error(err)
    );
  }


}
