import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateMyStoreAdComponent } from './create-my-store-ad.component';

describe('CreateMyStoreAdComponent', () => {
  let component: CreateMyStoreAdComponent;
  let fixture: ComponentFixture<CreateMyStoreAdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateMyStoreAdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateMyStoreAdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
