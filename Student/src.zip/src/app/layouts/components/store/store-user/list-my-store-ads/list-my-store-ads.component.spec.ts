import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListMyStoreAdsComponent } from './list-my-store-ads.component';

describe('ListMyStoreAdsComponent', () => {
  let component: ListMyStoreAdsComponent;
  let fixture: ComponentFixture<ListMyStoreAdsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListMyStoreAdsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListMyStoreAdsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
