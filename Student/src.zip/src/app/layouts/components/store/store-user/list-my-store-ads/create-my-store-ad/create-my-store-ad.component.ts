import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';
import swal from 'sweetalert';

@Component({
  selector: 'app-create-my-store-ad',
  templateUrl: './create-my-store-ad.component.html',
  styleUrls: ['./create-my-store-ad.component.scss']
})
export class CreateMyStoreAdComponent implements OnInit {

  public userid;
  public createad;
  public uploadimage;
  public category;
  public selectcategory;
  public campaign;
  public selectcampaign;
  createstoreadForm: FormGroup;
  submitted = false;
  @ViewChild('fileInput') fileInput: ElementRef;

  constructor(private _apiService: ApiService, private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    const currentUser = JSON.parse(localStorage.getItem('currentuser'));
    this.userid = currentUser.organisation_id;

    this.getcategory();
    this.getcampaign();
    // add store formgroup
    this.createstoreadForm = this.formBuilder.group({
      store_ad_name: ['', Validators.required],
      category_id: ['', Validators.required],
      store_ad_des: ['', Validators.required],
      store_id: [this.userid],
      start_date: ['', Validators.required],
      end_date: ['', Validators.required],
      campaign_id: ['', Validators.required],
      store_offer: ['', Validators.required],
      viewer_points: ['', Validators.required],
      ancestors_depth: ['', Validators.required],
      ancestors_points: ['', Validators.required],
      pop_ad: ['', Validators.required],
    });

  }

  get f() { return this.createstoreadForm.controls; }

  // get category
  getcategory() {
    this._apiService.listcategory('true').subscribe(
      res => {
        this.category = res;
        if (this.category.statuscode == 200) {
          this.selectcategory = this.category.data;
        }
      },
      err => console.error(err)
    );
  }

  // get campaign
  getcampaign() {
    this._apiService.listcampaign_on_brandid('true', this.userid).subscribe(
      res => {
        this.campaign = res;
        if (this.campaign.statuscode == 200) {
          this.selectcampaign = this.campaign.data;
        }
      },
      err => console.error(err)
    );
  }

  // update store image

  fileChange(e) {
    const image = e.target.files[0];
    this.createad = image;
    if (image) {
      const reader = new FileReader();
      reader.onload = () => {
        this.uploadimage = reader.result;
      };
      reader.readAsDataURL(image);
    } else {

    }
  }

  // create store ad

  onSubmit() {
    this.submitted = true;
    if (this.createstoreadForm.valid && this.uploadimage) {
      const file: File = this.createad;
      const createStoread: FormData = new FormData();
      createStoread.append('store_ad_name', this.createstoreadForm.value.store_ad_name);
      createStoread.append('store_id', this.userid);
      createStoread.append('category_id', this.createstoreadForm.value.category_id);
      createStoread.append('store_ad_des', this.createstoreadForm.value.store_ad_des);
      createStoread.append('start_date', this.createstoreadForm.value.start_date);
      createStoread.append('end_date', this.createstoreadForm.value.end_date);
      createStoread.append('image', file);
      createStoread.append('campaign_id', this.createstoreadForm.value.campaign_id);
      createStoread.append('store_offer', this.createstoreadForm.value.store_offer);
      createStoread.append('viewer_points', this.createstoreadForm.value.viewer_points);
      createStoread.append('ancestors_depth', this.createstoreadForm.value.ancestors_depth);
      createStoread.append('ancestors_points', this.createstoreadForm.value.ancestors_points);
      createStoread.append('pop_ad', this.createstoreadForm.value.pop_ad);

      this._apiService.createstoread(createStoread).subscribe((data: any) => {
        if (data.statuscode = 200) {
          swal({
            text: "StoreAd Created Successfully",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
          this.router.navigate(['/storeads']);
          this.createstoreadForm.reset();
        } else {
          swal({
            text: "Failed to Create StoreAd",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        }
      });
    } else {
      swal({
        text: "Some fields are empty.",
        buttons: [false],
        dangerMode: true,
        timer: 3000
      });
    }
  }

}