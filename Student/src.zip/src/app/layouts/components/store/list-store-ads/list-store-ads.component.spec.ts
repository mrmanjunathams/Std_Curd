import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListStoreAdsComponent } from './list-store-ads.component';

describe('ListStoreAdsComponent', () => {
  let component: ListStoreAdsComponent;
  let fixture: ComponentFixture<ListStoreAdsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListStoreAdsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListStoreAdsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
