import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';
import swal from 'sweetalert';

@Component({
  selector: 'app-list-store-ads',
  templateUrl: './list-store-ads.component.html',
  styleUrls: ['./list-store-ads.component.scss']
})
export class ListStoreAdsComponent implements OnInit {

  public storeads;
  displayedColumns = ['sno', 'store_ad_name', 'start_date', 'end_date', 'store_offer', 'action'];
  dataSource: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private _apiService: ApiService, private router: Router) { }

  ngOnInit() {
    this.getstoreads();
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  // view storead storead_id

  getstoread(store_ad_id) {
    localStorage.setItem('storead_id', store_ad_id);
    this.router.navigate(['/viewstoread']);
  }

  // get store ads
  getstoreads() {
    this._apiService.liststoreads('').subscribe(
      res => {
        this.storeads = res;
        if (this.storeads.statuscode == 200) {
          this.dataSource = new MatTableDataSource();
          this.dataSource.data = this.storeads.data;
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
        }
      },
      err => console.error(err)
    );
  }


  // disable storeads
  deletestoreads(store_ad_id, is_active) {
    if (store_ad_id && is_active) {
      if (is_active == 'true') {
        swal({
          text: "Are you sure?. Confirm to activate the storead.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.storeadsdelete(store_ad_id, is_active).subscribe((data: any) => {
                this.getstoreads();
                if (data.statuscode = 204) {
                  swal({
                    text: " StoreAd Activated Successfully",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Activate StoreAd",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      } else {
        swal({
          text: "Are you sure?. Confirm to deactivate the storead.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.storeadsdelete(store_ad_id, is_active).subscribe((data: any) => {
                this.getstoreads();
                if (data.statuscode = 204) {
                  swal({
                    text: "StoreAd Deactivated Successfully",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Deactivate StoreAd",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      }
    }
  }


}
