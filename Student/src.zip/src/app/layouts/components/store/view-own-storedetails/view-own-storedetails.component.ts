import { Component, OnInit, ViewChild } from '@angular/core';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';
import swal from 'sweetalert';
@Component({
  selector: 'app-view-own-storedetails',
  templateUrl: './view-own-storedetails.component.html',
  styleUrls: ['./view-own-storedetails.component.scss']
})
export class ViewOwnStoredetailsComponent implements OnInit {

  public storeid;
  public storedetails;
  public ownstore;
  public usertype;

  constructor(private _apiService: ApiService, private router: Router) { }


  ngOnInit() {
    const currentUser = JSON.parse(localStorage.getItem('currentuser'));
    this.usertype = currentUser.user_type;
    this.getownstoredetails();
  }

  // get own store details

  getownstoredetails() {
    this.storeid = localStorage.getItem('store_id');
    if (this.storeid) {
      this._apiService.getownstoredetails(this.storeid).subscribe(
        res => {
          this.storedetails = res;
          if (this.storedetails.statuscode == 200) {
            this.ownstore = this.storedetails.data;
          }
        },
        err => console.error(err)
      );
    } else {
    }
  }

  // disable store
  deletestore(store_id, is_active) {
    if (store_id && is_active) {
      if (is_active == 2) {
        swal({
          text: "Are you sure?. Confirm to activate the store.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if(value){
            this._apiService.storedelete(store_id, is_active).subscribe((data: any) => {
              this.getownstoredetails();
              if (data.statuscode = 204) {
                swal({
                  text: "Store Activated Successfully",
                  buttons: [false],
                  dangerMode: true,
                  timer: 3000
                });
              } else {
                swal({
                  text: "Failed to Activate Store",
                  buttons: [false],
                  dangerMode: true,
                  timer: 3000
                });
              }
            });
          }
          });
      } else {
        swal({
          text:"Are you sure?. Confirm to deactivate the store.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if(value){
            this._apiService.storedelete(store_id, is_active).subscribe((data: any) => {
              this.getownstoredetails();
              if (data.statuscode = 204) {
                swal({
                  text: "Store Deactivated Successfully",
                  buttons: [false],
                  dangerMode: true,
                  timer: 3000
                });
              } else {
                swal({
                  text: "Failed to Deactivate Store",
                  buttons: [false],
                  dangerMode: true,
                  timer: 3000
                });
              }
            });
          }
          });
      }
    }
  }
}
