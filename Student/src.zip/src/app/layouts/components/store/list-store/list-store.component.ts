import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';
import swal from 'sweetalert';

@Component({
  selector: 'app-list-store',
  templateUrl: './list-store.component.html',
  styleUrls: ['./list-store.component.scss']
})
export class ListStoreComponent implements OnInit {


  public store;
  displayedColumns = ['sno', 'store_name', 'store_email', 'store_phone','user_name', 'action'];
  dataSource: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private _apiService: ApiService, private router: Router) { }

  ngOnInit() {
    this.getstore();
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  // get store
  getstore() {
    this._apiService.liststore('1').subscribe(
      res => {
        this.store = res;
        if (this.store.statuscode == 200) {
          this.dataSource = new MatTableDataSource();
          this.dataSource.data = this.store.data;
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
        }
      },
      err => console.error(err)
    );
  }

  // disable store
  deletestore(store_id, is_active) {
    if (store_id && is_active) {
      if (is_active == 2) {
        swal({
          text: "Are you sure?. Confirm to activate the store.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
              this._apiService.storedelete(store_id, is_active).subscribe((data: any) => {
                this.getstore();
                if (data.statuscode = 204) {
                  swal({
                    text: "Store Activated Successfully",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                } else {
                  swal({
                    text: "Failed to Activate Store",
                    buttons: [false],
                    dangerMode: true,
                    timer: 3000
                  });
                }
              });
            }
          });
      } else {
        swal({
          text: "Are you sure?. Confirm to deactivate the store.",
          buttons: ['Cancel', 'Ok'],
          dangerMode: true,
          timer: 4000
        })
          .then((value) => {
            if (value) {
            this._apiService.storedelete(store_id, is_active).subscribe((data: any) => {
              this.getstore();
              if (data.statuscode = 204) {
                swal({
                  text: "Store Deactivated Successfully",
                  buttons: [false],
                  dangerMode: true,
                  timer: 3000
                });
              } else {
                swal({
                  text: "Failed to Deactivate Store",
                  buttons: [false],
                  dangerMode: true,
                  timer: 3000
                });
              }
            });
          }
          });
      }
    }
  }

  // view own store detail

  onClickownstoredetails(store_id) {
    if (store_id) {
      localStorage.setItem('store_id', store_id);
      this.router.navigate(['/viewstoredetail'])
    }
  }


}
