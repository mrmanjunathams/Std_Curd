import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListOwnStoreadsComponent } from './list-own-storeads.component';

describe('ListOwnStoreadsComponent', () => {
  let component: ListOwnStoreadsComponent;
  let fixture: ComponentFixture<ListOwnStoreadsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListOwnStoreadsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListOwnStoreadsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
