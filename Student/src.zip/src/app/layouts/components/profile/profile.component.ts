import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ApiService } from 'src/app/core/services/api-service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import swal from 'sweetalert';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {

  public user;
  public userprofile;
  public userid;
  public usertype;
  // uprofile = true;
  // cpwd = false;
  public username;
  public updateprofile
  public image;
  public usertypes;

  @ViewChild('fileInput') fileInput: ElementRef;
  updateForm: FormGroup;
  submitted = false;



  constructor(private formBuilder: FormBuilder, private _apiService: ApiService, private router: Router) { }

  ngOnInit() {
    const currentUser = JSON.parse(localStorage.getItem('currentuser'));
    this.userid = currentUser.user_id;
    this.usertype = currentUser.user_type;
    this.username = currentUser.username;
    this.getuser();

    this.updateForm = this.formBuilder.group({
      user_id: [this.userid],
      first_name: ['', Validators.required],
      last_name: ['', Validators.required],
      address: ['', Validators.required],
      mobile_number: ['', [Validators.required, Validators.pattern('[6-9]\\d{9}')]],
      organization_name: ['', Validators.required],
    });
  }

  get f() { return this.updateForm.controls; }

  // change password
  // toggle() {
  //   this.uprofile = false;
  //   this.cpwd = true;
  // }

  // update profile image

  fileChange(e) {
    const profiles = e.target.files;
    this.updateprofile = profiles;

  }

  // get userprofile details

  getuser() {
    this._apiService.getuserid(this.userid).subscribe(
      res => {
        this.user = res;
        if (this.user.statuscode == 200) {
          this.userprofile = this.user.data;
          if (this.userprofile.user_type == 'brand_admin') {
            this.usertypes = 'Brand Admin';
          } else if (this.userprofile.user_type == 'brand_user') {
            this.usertypes = 'Brand User';
          } else if (this.userprofile.user_type == 'admin') {
            this.usertypes = 'Admin';
          } else if (this.userprofile.user_type == 'store_user') {
            this.usertypes = 'Store User';
          } else if (this.userprofile.user_type == 'store_admin') {
            this.usertypes = 'Store Admin';
          }
          this.updateForm.setValue({
            user_id: this.userid,
            first_name: this.userprofile.first_name,
            last_name: this.userprofile.last_name,
            address: this.userprofile.address,
            mobile_number: this.userprofile.mobile_number,
            organization_name: this.userprofile.organization_name,
          });
        }
      },
      err => console.error(err)
    );
  }


  // update profile

  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.updateForm.valid) {
      const formData: FormData = new FormData();
      formData.append('user_id', this.userid);
      formData.append('first_name', this.updateForm.value.first_name);
      formData.append('last_name', this.updateForm.value.last_name);
      formData.append('address', this.updateForm.value.address);
      formData.append('mobile_number', this.updateForm.value.mobile_number);
      if (this.updateprofile) {
        const file: File = this.updateprofile[0];
        formData.append('image', file);
      } else {
        formData.append('image', '');
      }
      formData.append('organization_name', this.updateForm.value.organization_name);
      this._apiService.updateprofile(formData).subscribe((data: any) => {
        this.getuser();
        if (data.statuscode = 200) {
          swal({
            text: "Profile Updated Successfully",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        } else {
          swal({
            text: "Failed to Update Profile",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        }
      });
    }
  }
}


