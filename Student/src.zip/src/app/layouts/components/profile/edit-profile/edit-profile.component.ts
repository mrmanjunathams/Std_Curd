import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MustMatch } from 'src/app/core/models/must-match.validation';
import { ToastService } from 'src/app/core/modules/toast';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.scss']
})
export class EditProfileComponent implements OnInit {

  public users;
  public userprofiles;
  public updateprofile;
  public userid;
  @ViewChild('fileInput') fileInput: ElementRef;
  updateForm: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder, private toastService: ToastService, private _apiService: ApiService, private router: Router) { }

  ngOnInit() {
    const currentUser = JSON.parse(localStorage.getItem('currentuser'));
    this.userid = currentUser.user_id;
    this.getuser();

    this.updateForm = this.formBuilder.group({
      user_id: [this.userid],
      first_name: ['', Validators.required],
      last_name: ['', Validators.required],
      address: ['', Validators.required],
      mobile_number: ['', Validators.required],
      organization_name: ['', Validators.required],
    });

  }

  get f() { return this.updateForm.controls; }

  // get userprofile details

  getuser() {
    this._apiService.getuserid(this.userid).subscribe(
      res => {
        this.users = res;
        if (this.users.statuscode = 200) {
          this.userprofiles = this.users.data;
          console.log('updateprofiles', this.userprofiles);
          this.updateForm.setValue({
            user_id: this.userid,
            first_name: this.userprofiles.first_name,
            last_name: this.userprofiles.last_name,
            address: this.userprofiles.address,
            mobile_number: this.userprofiles.mobile_number,
            organization_name: this.userprofiles.organization_name,
          });
        }
      },
      err => console.error(err)
    );
  }

  // update profile image

  fileChange(e) {
    const profiles = e.target.files;
    this.updateprofile = profiles;
  }

  // update profile

  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.updateForm.valid) {
      const file: File =  this.updateprofile[0];
      const formData: FormData = new FormData();
      formData.append('user_id', this.userid);
      formData.append('first_name', this.updateForm.value.first_name);
      formData.append('last_name', this.updateForm.value.last_name);
      formData.append('address', this.updateForm.value.address);
      formData.append('mobile_number', this.updateForm.value.mobile_number);
      formData.append('image', file );
      formData.append('organization_name', this.updateForm.value.organization_name);
      this._apiService.updateprofile(formData).subscribe((data: any) => {
        this.getuser();
        this.router.navigate(['/profile']);
        if (data.statuscode == 200) {
          this.toastService.show({
            text: `${data.msg}`,
            type: 'success',
          });
        } else {
          this.toastService.show({
            text: `${data.msg}`,
            type: 'warning',
          });
        }
      });
    }
  }
}
