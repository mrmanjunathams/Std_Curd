import { Component, OnInit, ViewChild } from '@angular/core';
import { ApiService } from 'src/app/core/services/api-service';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { Router } from '@angular/router';
import { ToastService } from 'src/app/core/modules/toast';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  public usertype;
  public organisationid;
  public listcount;
  public counts;
  public brandcount ;
  public brandadcount;
  public campaigncount;
  public customercount;
  public popadcount;
  public storecount;
  public storeadcount;
  public tagcount;
  public brandads;
  public brand_ads;
  public brand_adcounts;
  public list_count;
  public userid;
  public tag_count;
  public tag_counts;
  public store_adcounts;
  public pop_adcount;
  public store_counts;
  public campaign_counts;
  public store_adcount;
  public campaign_countt;
  dataSource: any;

  constructor(private _apiService: ApiService, private router: Router) { }

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  ngOnInit() {
    const currentUser = JSON.parse(localStorage.getItem('currentuser'));
    this.usertype = currentUser.user_type;
    this.userid = currentUser.user_id;
    this.organisationid = currentUser.organisation_id;

    this.getcounts();
    this.get_on_brand_id();
    this.get_on_store_id();

    this.doughnutChartType = 'doughnut';
    this.radarChartType = 'radar';
  }

  // Doughnut
  public doughnutChartLabels: string[] = ['Download Sales', 'In-Store Sales', 'Mail-Order Sales'];
  public doughnutChartData: number[] = [350, 450, 100];
  public doughnutChartType: string;

  // Radar
  public radarChartLabels: string[] = [
    'Eating',
    'Drinking',
    'Sleeping',
    'Designing',
    'Coding',
    'Cycling',
    'Running'
  ];
  public radarChartData: any = [
    { data: [65, 59, 90, 81, 56, 55, 40], label: 'Series A' },
    { data: [28, 48, 40, 19, 96, 27, 100], label: 'Series B' }
  ];
  public radarChartType: string;

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  // counts

  getcounts() {
    this._apiService.getcount().subscribe(
      res => {
        this.listcount = res['data'];
            this.brandcount = this.listcount.brand_count;
            this.brandadcount = this.listcount.brandad_count;
            this.campaigncount = this.listcount.campaign_count;
            this.customercount = this.listcount.customer_count;
            this.popadcount = this.listcount.pop_ad_count;
            this.storecount = this.listcount.store_count;
            this.storeadcount = this.listcount.storead_count;
            this.tagcount = this.listcount.tag_count;
      },
      err => console.error(err)
    );
  }

  get_on_brand_id() {
    this._apiService.getbrands(this.organisationid).subscribe(
      res => {
        this.list_count = res['data'];
          this.brand_adcounts = this.list_count.brand_ad_count;
          this.tag_counts = this.list_count.tag_count;
          this.campaign_counts = this.list_count.campaign_count;
          this.store_counts = this.list_count.store_count;
      },
      err => console.error(err)
    );
  }

   get_on_store_id() {
    this._apiService.getstoreads(this.organisationid).subscribe(
      res => {
        this.list_count = res['data'];
          this.pop_adcount = this.list_count.pop_ad_count;
          this.store_adcount = this.list_count.store_ad_count;
          this.campaign_countt = this.list_count.campaign_count;
      },
      err => console.error(err)
    );
  }


}
