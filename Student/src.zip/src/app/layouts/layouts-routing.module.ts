import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LayoutsComponent } from './layouts.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AuthGuard } from '../core/guard';
import { ProfileComponent } from './components/profile/profile.component';
import { ChangePasswordComponent } from '../components/change-password/change-password.component';
import { ListBrandComponent } from './components/brand/list-brand/list-brand.component';
import { CustomerComponent } from './components/customer/customer.component';
import { ListStoreComponent } from './components/store/list-store/list-store.component';
import { ListBrandAdsComponent } from './components/brand/list-brand-ads/list-brand-ads.component';
import { CategoryComponent } from './components/category/category.component';
import { ListStoreAdsComponent } from './components/store/list-store-ads/list-store-ads.component';
import { UserComponent } from './components/user/user.component';
import { TagComponent } from './components/tag/tag.component';
import { ViewBrandComponent } from './components/brand/list-brand/view-brand/view-brand.component';
import { CreateBrandComponent } from './components/brand/list-brand/create-brand/create-brand.component';
import { StoreComponent } from './components/brand/brandstore/store.component';
import { CompaignComponent } from './components/compaign/compaign.component';
import { BrandadComponent } from './components/brand/brandad/brandad.component';
import { CreatestoreComponent } from './components/brand/brandstore/createstore/createstore.component';
import { CreatebrandadComponent } from './components/brand/brandad/createbrandad/createbrandad.component';
import { ViewOwnStoredetailsComponent } from './components/store/view-own-storedetails/view-own-storedetails.component';
import { ViewBrandadComponent } from './components/brand/brandad/view-brandad/view-brandad.component';
// import { BrandUserManagementComponent } from './components/usermanagement/brand-user-management/brand-user-management.component';
// import { CreateBrandUserComponent } from './components/usermanagement/brand-user-management/create-brand-user/create-brand-user.component';
// import { CreateAdminUserComponent } from './components/usermanagement/admin-user-management/create-admin-user/create-admin-user.component';
// import { AdminUserManagementComponent } from './components/usermanagement/admin-user-management/admin-user-management.component';
import { ListMyStoreAdsComponent } from './components/store/store-user/list-my-store-ads/list-my-store-ads.component';
import { CreateMyStoreAdComponent } from './components/store/store-user/list-my-store-ads/create-my-store-ad/create-my-store-ad.component';
// import { StoreUserComponent } from './components/usermanagement/store-user/store-user.component';
import { ViewStoreadsComponent } from './components/store/store-user/view-storeads/view-storeads.component';
import { UsermanagementComponent } from './components/usermanagement/usermanagement.component';
import { CreateuserComponent } from './components/usermanagement/createuser/createuser.component';

const routes: Routes = [
    {
        path: '',
        component: LayoutsComponent,
        children: [
            {
                path: '',
                redirectTo: 'dashboard'
            },
            {
                path: 'dashboard',
                component: DashboardComponent
            },
            {
                path: 'profile',
                component: ProfileComponent
            },
            {
                path: 'changepwd',
                component: ChangePasswordComponent
            },
            {
                path: 'listbrand',
                component: ListBrandComponent
            },
            {
                path: 'customer',
                component: CustomerComponent
            },
            {
                path: 'user',
                component: UserComponent
            },
            {
                path: 'liststore',
                component: ListStoreComponent
            },
            {
                path: 'listbrandads',
                component: ListBrandAdsComponent
            },
            {
                path: 'liststoreads',
                component: ListStoreAdsComponent
            },
            {
                path: 'category',
                component: CategoryComponent
            },
            {
                path: 'tags',
                component: TagComponent
            },
            {
                path: 'viewbrand',
                component: ViewBrandComponent
            },
            {
                path: 'createbrand',
                component: CreateBrandComponent
            },
            {
                path: 'store',
                component: StoreComponent
            },
            {
                path: 'campaign',
                component: CompaignComponent
            },
            {
                path: 'brandad',
                component: BrandadComponent
            },
            {
                path: 'createstore',
                component: CreatestoreComponent
            },
            {
                path: 'createbrandad',
                component: CreatebrandadComponent
            },
            {
                path: 'viewstoredetail',
                component: ViewOwnStoredetailsComponent
            },
            {
                path: 'viewbrandad',
                component: ViewBrandadComponent
            },
            {
                path: 'users',
                component: UsermanagementComponent
            },
            {
                path: 'createuser',
                component: CreateuserComponent
            },
            {
                path: 'storeads',
                component: ListMyStoreAdsComponent
            },
            {
                path: 'createstoread',
                component: CreateMyStoreAdComponent
            },    
            {
                path: 'viewstoread',
                component: ViewStoreadsComponent
            },
        ],
        canActivate: [AuthGuard]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
    providers: [AuthGuard]
})
export class LayoutRoutingModule { }
