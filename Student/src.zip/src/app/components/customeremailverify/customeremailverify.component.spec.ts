import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomeremailverifyComponent } from './customeremailverify.component';

describe('CustomeremailverifyComponent', () => {
  let component: CustomeremailverifyComponent;
  let fixture: ComponentFixture<CustomeremailverifyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomeremailverifyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomeremailverifyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
