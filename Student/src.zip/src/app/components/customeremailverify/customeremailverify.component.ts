import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from 'src/app/core/services/api-service';

@Component({
  selector: 'app-customeremailverify',
  templateUrl: './customeremailverify.component.html',
  styleUrls: ['./customeremailverify.component.scss']
})
export class CustomeremailverifyComponent implements OnInit {

  public passtoken;
  public message;
  public header;

  constructor(private route: ActivatedRoute, private router: Router, private _apiService: ApiService) { }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.passtoken = params['hash'];
      this._apiService.customemailverify(this.passtoken).subscribe((data: any) => {
        if (data.statuscode == 204) {
          this.header = "Thank you";
          this.message = "Your account has been verified successfully!.";
        } else {
          this.header = "Verification Failed!";
          this.message = "Your account has not been verified!. Please try later.";
        }
      });
    });
  }  
}
