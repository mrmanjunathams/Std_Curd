import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from 'src/app/core/services/api-service';
import { Router, ActivatedRoute } from '@angular/router';

import swal from 'sweetalert';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  type = "password";
  show = false;
  loginForm: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder, private _apiService: ApiService, private router: Router) {
  }

  toggleShow() {
    this.show = !this.show;
    if (this.show) {
      this.type = "text";
    }
    else {
      this.type = "password";
    }
  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  get f() { return this.loginForm.controls; }

  onSubmit() {
    this.submitted = true;
    if (this.loginForm.valid) {
      this._apiService.login(this.loginForm.value).subscribe((data: any) => {
        if (data.statuscode == 200) {
          localStorage.setItem('token', data.data['jwt_token']);
          localStorage.setItem('currentuser', JSON.stringify(data.data));
          swal({
            text: "Login Successful.",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
          window.location.replace('/dashboard');         
        } else if (data.statuscode == 203) {
          swal({
            text: "Invalid Username & Password. Please try again.",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        }
        else if (data.statuscode == 500) {
          swal({
            text: "Something went wrong! Please try again.",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        }
      });
    }

  }

}


