import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from 'src/app/core/services/api-service';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { MustMatch } from 'src/app/core/models/must-match.validation';

import swal from 'sweetalert';
@Component({
  selector: 'app-customerresetpwd',
  templateUrl: './customerresetpwd.component.html',
  styleUrls: ['./customerresetpwd.component.scss']
})
export class CustomerresetpwdComponent implements OnInit {

  type = "password";
  show = false;
  public hash;

  resetForm: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder, private _apiService: ApiService, private router: Router, private route: ActivatedRoute) { }

  toggleShow() {
    this.show = !this.show;
    if (this.show) {
      this.type = "text";
    }
    else {
      this.type = "password";
    }
  }
  
  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.hash = params['hash'];
    });
  
    this.resetForm = this.formBuilder.group({
      newpassword: ['', [Validators.required, Validators.minLength(8)]],
      confirmpassword: ['', Validators.required],
      resetpasswordtoken: [this.hash, Validators.required],
    }, {
      validator: MustMatch('newpassword', 'confirmpassword')
    });
  }

  get f() { return this.resetForm.controls; }

  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.resetForm.valid) {
      this._apiService.customerreset(this.resetForm.value).subscribe((data: any) => {
        if (data.statuscode == 204) {
          this.resetForm.reset();
          swal({
            text: `Password reset successfully. Login to continue.`,
            buttons: [false],
            dangerMode: true,
            timer: 4000
          });
        } else {
          swal({
            text: "Failed to Reset Password",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        }
      },
        (err: HttpErrorResponse) => {

        });
    }
  }

}
