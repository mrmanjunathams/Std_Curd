import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerresetpwdComponent } from './customerresetpwd.component';

describe('CustomerresetpwdComponent', () => {
  let component: CustomerresetpwdComponent;
  let fixture: ComponentFixture<CustomerresetpwdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerresetpwdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerresetpwdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
