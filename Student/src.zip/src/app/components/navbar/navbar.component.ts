import { Component, OnInit, ViewChild } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/core/services/api-service';
import { map } from 'rxjs/operators';
import { NavigationEnd, Router } from '@angular/router';
import { MatSidenavContainer } from '@angular/material';


@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {
  @ViewChild(MatSidenavContainer) sidenavContainer: MatSidenavContainer;
  showMenu: boolean = false;
  public currentuser;
  public usertype;
  public user;
  public userprofile;
  public userid;
  public currentUser;
  showSubmenu: boolean = false;
  showadsMenu: boolean = false;
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches)
    );

  constructor(private breakpointObserver: BreakpointObserver, private _apiService: ApiService, private router: Router) { }

  ngOnInit() {
    this.currentUser = JSON.parse(localStorage.getItem('currentuser'));
    this.usertype = this.currentUser.user_type;
    this.userid = this.currentUser.user_id;
    this.getuser();
  }

  logout() {
    localStorage.removeItem('currentuser');
    localStorage.removeItem('token');
    localStorage.removeItem('brand_id');
    localStorage.removeItem('brandad_id');
    localStorage.removeItem('store_id');
    localStorage.removeItem('storead_id');
    window.location.href = '/';
  }

  clickprofile() {
    this.router.navigate(['/profile']);
  }

  getuser() {
    this._apiService.getuserid(this.userid).subscribe(
      res => {
        this.user = res;
        if (this.user.statuscode == 200) {
          this.userprofile = this.user.data['user_img'];         
        }
      },
      err => console.error(err)
    );
  }
}
