import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from 'src/app/core/services/api-service';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { MustMatch } from 'src/app/core/models/must-match.validation';
import swal from 'sweetalert';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit {

  type = "password";
  show = false;
  public hash;
  public username;

  changepasswordForm: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder, private _apiService: ApiService, private router: Router, private route: ActivatedRoute) { }

  toggleShow() {
    this.show = !this.show;
    if (this.show) {
      this.type = "text";
    }
    else {
      this.type = "password";
    }
  }

  ngOnInit() {

    const currentUser = JSON.parse(localStorage.getItem('currentuser'));
    this.username = currentUser.username;
    this.changepasswordForm = this.formBuilder.group({
      username: [this.username],
      password: ['', Validators.required],
      newpassword: ['', [Validators.required, Validators.minLength(8)]],
      confirmpassword: ['', Validators.required],
    }, {
        validator: MustMatch('newpassword', 'confirmpassword')
      });
  }

  get f() { return this.changepasswordForm.controls; }

  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.changepasswordForm.valid) {
      this._apiService.changepassword(this.changepasswordForm.value).subscribe((data: any) => {
        if (data.statuscode == 204) {
          localStorage.removeItem('currentuser');
          localStorage.removeItem('token');
          localStorage.removeItem('store_id');
          localStorage.removeItem('brand_id');
          localStorage.removeItem('brandad_id');
          this.router.navigate(['/login']);
          this.changepasswordForm.reset();
          swal({
            text: "Password Changed Successfully !",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        } else if(data.statuscode == 404) {
          swal({
            text: "Invalid Current Password. Please try again.",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        } else {
          swal({
            text: "Failed to change password.",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        }
      },
        (err: HttpErrorResponse) => {

        });
    }
  }

}
