import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MustMatch } from 'src/app/core/models/must-match.validation';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import swal from 'sweetalert';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  type = "password";
  show = false;

  signupForm: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder, private _apiService: ApiService, private router: Router) { }

  toggleShow() {
    this.show = !this.show;
    if (this.show) {
      this.type = "text";
    }
    else {
      this.type = "password";
    }
  }

  ngOnInit() {
    this.signupForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      user_type: ['', Validators.required],
      organization_name: ['', Validators.required],
      organisation_gst: ['', Validators.required],
      mobile_number: ['', [Validators.required, Validators.pattern('[6-9]\\d{9}')]],
    }, {
        validator: MustMatch('password', 'confirmPassword')
      });
  }

  get f() { return this.signupForm.controls; }

  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    console.log(this.signupForm.value);
    if (this.signupForm.valid) {
      this._apiService.signup(this.signupForm.value).subscribe((data: any) => {       
        
        if (data.statuscode == 200) {
          swal({
            text: "Succesfully created a new account. Please check your email to verify.",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
          this.router.navigate(['/login']);
          this.signupForm.reset();          
        } else if (data.statuscode == 203) {
          swal({
            text: "User already exist.",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        } else {
          swal({
            text: "Something went wrong! Please try again.",
            buttons: [false],
            dangerMode: true,
            timer: 3000
          });
        }
      },
        (err: HttpErrorResponse) => {
         
        });
    }
  }
}
