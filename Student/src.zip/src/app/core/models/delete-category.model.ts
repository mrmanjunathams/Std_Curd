export interface DeleteCategoryForm {
    category_id: string;
    is_active: string;
}
