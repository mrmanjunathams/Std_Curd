export interface ForgotForm {
    email: string;
}
