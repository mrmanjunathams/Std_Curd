export interface CampaignForm {
    is_active: string;
    _id: string;
    created_at: string;
    campaign_id: string;
    campaign_name: string;
    start_date: string;
    end_date: string;
    store_id:string;
    brand_id:string;
}
