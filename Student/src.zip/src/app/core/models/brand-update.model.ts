export interface BrandupdateForm {
    brand_id: string,
    brand_name: string,
    brand_logo: string,
    user_name: string
}
