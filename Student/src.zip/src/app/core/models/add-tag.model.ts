export interface TagForm {
    brand_id: string;
    is_active: string;
    _id: string;
    created_at: string;
    tag_id: string;
    tag_name: string;
}
