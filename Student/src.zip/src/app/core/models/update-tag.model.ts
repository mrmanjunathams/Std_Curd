export interface UpdateTagForm {
    tag_id: string;
    tag_name: string;
}