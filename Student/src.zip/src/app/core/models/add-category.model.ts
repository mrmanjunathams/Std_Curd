export interface CategoryForm {
    is_active: string;
    _id: string;
    created_at: string;
    category_id: string;
    category_name: string;
}
