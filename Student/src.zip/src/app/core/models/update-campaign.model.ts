export interface UpdateCampaignForm {
    campaign_id: string;
    campaign_name: string;
}