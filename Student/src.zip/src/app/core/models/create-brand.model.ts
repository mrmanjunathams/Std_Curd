export interface CreateBrandForm {
    brand_name: string;
    brand_logo: string;
    user_name: string;
    brand_gst: string;
}
