export interface CreateStoreAdForm {
  
}
