export interface BranduserForm {
    approved_by: string;
    username: string;
    mobile_number: string;
    email: string;
    organization_name: string;
    organisation_gst: string;   
}
