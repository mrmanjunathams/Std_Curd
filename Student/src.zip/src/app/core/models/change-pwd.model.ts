export interface ChangepwForm {
    username: string;
    password: string;
    newpassword: string;
    confirmpassword: string;
}
