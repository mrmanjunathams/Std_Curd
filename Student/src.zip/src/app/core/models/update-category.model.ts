export interface UpdateCategoryForm {
    category_id: string;
    category_name: string;
}