export interface EmailVerifyForm {
    passtoken: string;
}
