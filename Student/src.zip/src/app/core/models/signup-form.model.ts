export interface SignupForm {
    username: string;
    password: string;
    confirmPassword: string;
    email: string;
    user_type: string;
    organization_name: string;
    organisation_gst: string;
    mobile_number: number;
}
