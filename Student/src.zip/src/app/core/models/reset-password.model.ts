export interface ResetForm {
    newpassword: string;
    confirmpassword: string;
    resetpasswordtoken: string;
}
