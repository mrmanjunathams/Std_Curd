export interface AdminForm {
    user_id: string;
    approved_by: string;
    username: string;
    organization_name:string;
    email: string;
    mobile_number: string;  
}
