import { Injectable, NgModule } from '@angular/core';
import { Http, Headers, RequestOptionsArgs, RequestOptions, Response } from '@angular/http';
import { HttpClient, HttpHeaders } from '@angular/common/http';

// models
import { LoginForm } from '../models/login-form.model';
import { SignupForm } from '../models/signup-form.model';
import { ForgotForm } from '../models/forgot-password.model';
import { ResetForm } from '../models/reset-password.model';
import { EmailVerifyForm } from '../models/email-verify.model';
import { CategoryForm } from '../models/add-category.model';
import { CampaignForm } from '../models/add-campaign.model';
import { UpdateCategoryForm } from '../models/update-category.model';
import { ChangepwForm } from '../models/change-pwd.model';
import { UpdateTagForm } from '../models/update-tag.model';
import { TagForm } from '../models/add-tag.model';
import { BrandupdateForm } from '../models/brand-update.model';
import { UpdateCampaignForm } from '../models/update-campaign.model'
import { AdminForm } from '../models/add-admin.model';
import { BranduserForm } from '../models/add-branduser.model';

// const devUrl = 'http://localhost:8005/smartads/api/v1';

const devUrl = 'http://35.200.185.202:8005/smartads/api/v1';

// const devUrl = 'http://192.168.0.188:8001/smartads/api/v1';

const httpOptions = {
    headers: new Headers({ 'Authorization': localStorage.getItem('token') || '' })
};

const httpOptionss = {
    headers: new Headers({ 'Content-Type': 'application/json;charset=utf-8', 'Authorization': localStorage.getItem('token') || '' })
};

const httpOptionsClient = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json;charset=utf-8', 'Authorization': localStorage.getItem('token') || '' })
};

// const httpOptionsClients = {
//     headers: new HttpHeaders({ 'Content-Type': 'application/json;charset=utf-8' })
// };



@NgModule({ providers: [ApiService] })
@Injectable({
    providedIn: 'root'
})

export class ApiService {

    constructor(private http: Http, private httpclient: HttpClient) {

    }

    // login & register & forgot password & reset password

    login(loginForm: LoginForm) {
        return this.httpclient.post(devUrl + '/userlogin', loginForm, httpOptionsClient);
    }

    signup(signupForm: SignupForm) {
        return this.httpclient.post(devUrl + '/usersignup', signupForm, httpOptionsClient);
    }

    branduser(createbranduserForm: BranduserForm) {
        return this.httpclient.post(devUrl + '/add_brand', createbranduserForm, httpOptionsClient);
    }

    createadmin(createadminForm: AdminForm) {
        return this.httpclient.post(devUrl + '/add_user', createadminForm, httpOptionsClient);
    }

    forgot(forgotForm: ForgotForm) {
        return this.httpclient.post(devUrl + '/user_forgotpassword', forgotForm, httpOptionsClient);
    }

    reset(resetForm: ResetForm) {
        return this.httpclient.post(devUrl + '/user_resetpassword', resetForm, httpOptionsClient);
    }

    customerreset(resetForm: ResetForm) {
        return this.httpclient.post(devUrl + '/customer_resetpassword', resetForm, httpOptionsClient);
    }
    // email verification

    emailverify(passtoken: EmailVerifyForm) {
        const body = JSON.stringify({ passtoken });
        return this.httpclient.post(devUrl + '/user_emailverification', body, httpOptionsClient);
    }

    customemailverify(passtoken: EmailVerifyForm) {
        const body = JSON.stringify({ passtoken });
        return this.httpclient.post(devUrl + '/customer_emailverification', body, httpOptionsClient);
    }

    // change password
    changepassword(changepasswordForm: ChangepwForm) {
        return this.httpclient.post(devUrl + '/user_changepassword', changepasswordForm, httpOptionsClient);
    }

    // count api

    getcount() {
        return this.httpclient.get(devUrl + '/active_counts', httpOptionsClient);
    }

    getbrands(organisationid) {
        return this.httpclient.get(devUrl + '/count_on_brand_id?brand_id=' + organisationid, httpOptionsClient);
    }

    gettags(brand_id) {
        return this.httpclient.get(devUrl + '/count_tag?brand_id=' + brand_id, httpOptionsClient);
    }

    getstoreads(organisationid) {
        return this.httpclient.get(devUrl + '/count_on_store_id?store_id=' + organisationid, httpOptionsClient);
    }
    // getpopads(store_id) {
    //     return this.httpclient.get(devUrl + '/count_pop_ad?store_id=' + store_id, httpOptionsClient);
    // }
    // list api

    listbrand(active) {
        return this.httpclient.get(devUrl + '/list_brand?is_active=' + active, httpOptionsClient);
    }

    listbrandad(brandadid) {
        return this.httpclient.get(devUrl + '/get_brand_ad?brand_ad_id=' + brandadid, httpOptionsClient);
    }

    listuser(is_active) {
        return this.httpclient.get(devUrl + '/list_user?is_active=' + is_active, httpOptionsClient);
    }

    listbrandads(active) {
        return this.httpclient.get(devUrl + '/list_brand_ad?is_active=' + active, httpOptionsClient);
    }

    listcustomer(active) {
        return this.httpclient.get(devUrl + '/list_customers?offset=0&is_active=' + active, httpOptionsClient);
    }

    listcampaign(active) {
        return this.httpclient.get(devUrl + '/list_campaign?offset=0&is_active=' + active, httpOptionsClient);
    }

    listcampaign_on_storeid(active, store_id) {
        return this.httpclient.get(devUrl + '/get_campaign_on_store_id?offset=0&is_active=' + active + '&store_id=' + store_id, httpOptionsClient);
    }

    listcampaign_on_brandid(active, brand_id) {
        return this.httpclient.get(devUrl + '/get_campaign_on_brand_id?offset=0&is_active=' + active + '&brand_id=' + brand_id, httpOptionsClient);
    }

    liststore(active) {
        return this.httpclient.get(devUrl + '/list_stores?store_is_active=' + active, httpOptionsClient);
    }

    liststoreads(active) {
        return this.httpclient.get(devUrl + '/list_store_ads?is_active=' + active, httpOptionsClient);
    }

    listcategory(active) {
        return this.httpclient.get(devUrl + '/list_category?is_active=' + active, httpOptionsClient);
    }
    listtag(active) {
        return this.httpclient.get(devUrl + '/list_tag?is_active=' + active, httpOptionsClient);
    }

    listcount() {
        return this.httpclient.get(devUrl + '/active_counts', httpOptionsClient);
    }

    getuserid(userid) {
        return this.httpclient.get(devUrl + '/get_user?user_id=' + userid, httpOptionsClient);
    }

    listtopbrandads(active) {
        var count = 5;
        return this.httpclient.get(devUrl + '/list_brand_ad?is_active=' + active + '&count=' + count, httpOptionsClient);
    }

    listtopstoreads(active) {
        var count = 5;
        return this.httpclient.get(devUrl + '/list_store_ads?is_active=' + '&count=' + count, httpOptionsClient);
    }

    listbranduser(brandid) {
        return this.httpclient.get(devUrl + '/list_users_brand_gst?brand_id=' + brandid, httpOptionsClient);
    }

    getownbrandads(is_active, brand_id) {
        return this.httpclient.get(devUrl + '/list_brand_ads_on_brand_id?is_active=' + is_active + '&brand_id=' + brand_id, httpOptionsClient);
    }

    listadminuser(is_active, organisation) {
        return this.httpclient.get(devUrl + '/list_subuser?is_active=' + is_active + '&brand_id=' + organisation,  httpOptionsClient);
    }

    listpopads(active) {
        return this.httpclient.get(devUrl + '/list_instant_ads?is_active=' + active, httpOptionsClient);
    }



    // get store-detail-using brand id
    getownbrand(brand_id) {
        return this.httpclient.get(devUrl + '/get_brand?brand_id=' + brand_id, httpOptionsClient);
    }

    // get storead details
    getstoread(store_ad_id) {
        return this.httpclient.get(devUrl + '/get_store_ads?store_ad_id=' + store_ad_id, httpOptionsClient);
    }

    // get own store details
    getownstoredetails(storeid) {
        return this.httpclient.get(devUrl + '/get_store?store_id=' + storeid, httpOptionsClient);
    }

    // get own store ads 
    getownstoreads(is_active, store_id) {
        return this.httpclient.get(devUrl + '/list_store_ads_on_store_id?is_active=' + is_active + '&store_id=' + store_id, httpOptionsClient);
    }

    // add api
    categoryadd(categoryForm: CategoryForm) {
        return this.httpclient.post(devUrl + '/add_category', categoryForm, httpOptionsClient);
    }
    campaignadd(campaignForm: CampaignForm) {
        return this.httpclient.post(devUrl + '/add_campaign', campaignForm, httpOptionsClient);
    }

    createbrand(createBrand) {
        return this.httpclient.post(devUrl + '/add_brand', createBrand, httpOptionsClient);
    }

    tagadd(tagForm: TagForm) {
        return this.httpclient.post(devUrl + '/add_tag', tagForm, httpOptionsClient);
    }

    createstore(createStore) {
        return this.http.post(devUrl + '/add_store', createStore, httpOptions);
    }

    createbrandads(createBrandad) {
        return this.http.post(devUrl + '/add_brand_ad', createBrandad, httpOptions);
    }

    createstoread(createStoread) {
        return this.http.post(devUrl + '/add_store_ads', createStoread, httpOptions);
    }


    // update api

    categoryupdate(editcategoryForm: UpdateCategoryForm) {
        return this.httpclient.post(devUrl + '/update_category', editcategoryForm, httpOptionsClient);
    }

    campaignupdate(editcampaignForm: UpdateCampaignForm) {
        return this.httpclient.post(devUrl + '/update_campaign', editcampaignForm, httpOptionsClient);
    }
    brandupdate(updateBrand) {
        return this.http.post(devUrl + '/update_brand', updateBrand, httpOptions);
    }

    updateprofile(formData) {
        return this.http.post(devUrl + '/update_user', formData, httpOptions);
    }

    updatebrandads(updateBrandad) {
        return this.http.post(devUrl + '/update_brand_ad', updateBrandad, httpOptions);
    }


    updateownstoredetails(updateStore) {
        return this.http.post(devUrl + '/update_store', updateStore, httpOptions);
    }

    tagupdate(edittagForm: UpdateTagForm) {
        return this.httpclient.post(devUrl + '/update_tag', edittagForm, httpOptionsClient);
    }

    updatestoread(updateStoread) {
        return this.http.post(devUrl + '/update_store_ads', updateStoread, httpOptions);
    }


    // perticular brand storeview api

    listbrandstores(is_active, brand_id) {
        return this.httpclient.get(devUrl + '/list_stores_brand_id?is_active=+' + is_active + '&brand_id=' + brand_id, httpOptionsClient);
    }

    // approval api

    userapproval(user_id, is_active) {
        const body = JSON.stringify({ user_id, is_active });
        return this.httpclient.post(devUrl + '/approve_user', body, httpOptionsClient);
    }


    // delete(disable and enable) api

    userdelete(user_id, is_active) {
        const body = JSON.stringify({ user_id, is_active });
        return this.httpclient.post(devUrl + '/delete_user', body, httpOptionsClient);
    }

    categorydisable(category_id, is_active) {
        const body = JSON.stringify({ category_id, is_active });
        return this.httpclient.post(devUrl + '/delete_category', body, httpOptionsClient);
    }

    branddelete(brand_id, is_active) {
        const body = JSON.stringify({ brand_id, is_active });
        return this.httpclient.post(devUrl + '/delete_brand', body, httpOptionsClient);
    }

    customerdisable(customer_id, is_active) {
        const body = JSON.stringify({ customer_id, is_active });
        return this.httpclient.post(devUrl + '/delete_customer', body, httpOptionsClient);
    }
    campaigndisable(campaign_id, is_active) {
        const body = JSON.stringify({ campaign_id, is_active });
        return this.httpclient.post(devUrl + '/delete_campaign', body, httpOptionsClient);
    }
    tagdisable(tag_id, is_active) {
        const body = JSON.stringify({ tag_id, is_active });
        return this.httpclient.post(devUrl + '/delete_tag', body, httpOptionsClient);
    }

    brandadsdelete(brand_ad_id, is_active) {
        const body = JSON.stringify({ brand_ad_id, is_active });
        return this.httpclient.post(devUrl + '/delete_brand_ad', body, httpOptionsClient);
    }

    storedelete(store_id, is_active) {
        const body = JSON.stringify({ store_id, is_active });
        return this.httpclient.post(devUrl + '/delete_store', body, httpOptionsClient);
    }

    storeadsdelete(store_ad_id, is_active) {
        const body = JSON.stringify({ store_ad_id, is_active });
        return this.httpclient.post(devUrl + '/delete_store_ads', body, httpOptionsClient);
    }

    popadsdelete(store_ad_id, pop_ad) {
        const body = JSON.stringify({ store_ad_id, pop_ad });
        return this.httpclient.post(devUrl + '/update_instant_ads', body, httpOptionsClient);
    }


}  