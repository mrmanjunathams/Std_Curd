import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-new-user',
  templateUrl: './new-user.component.html',
  styleUrls: ['./new-user.component.scss']
})
export class NewUserComponent implements OnInit {

  public user;
  displayedColumns = ['sno', 'email', 'action'];
  dataSource: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private _apiService: ApiService, private router: Router) { }

  ngOnInit() {
    this.getuser();
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  // get brand ads
  getuser() {
    this._apiService.listuser('1').subscribe(
      res => {
        this.user = res;
        if (this.user.statuscode == 200) {
          this.dataSource = new MatTableDataSource();
          this.dataSource.data = this.user.data;
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
        }
      },
      err => console.error(err)
    );
  }

  // approval api

  approve(user_id, is_active) {
    if (user_id && is_active) {
      this._apiService.userapproval(user_id, is_active).subscribe((data: any) => {
        if (data.statuscode = 204) {
          this.getuser();
         

        } else {
          
        }
      });
    }
  }

  // active and deactive

  delete(user_id, is_active) {
    if (user_id && is_active) {
      this._apiService.userdelete(user_id, is_active).subscribe((data: any) => {
        this.getuser();
        if (data.statuscode = 204) {    
       

        } else {
         
        }
      });
    }
  }

}
