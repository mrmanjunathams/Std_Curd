import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-new-brand',
  templateUrl: './new-brand.component.html',
  styleUrls: ['./new-brand.component.scss']
})
export class NewBrandComponent implements OnInit {

  public brandads;
  displayedColumns = ['sno', 'brand_ad_name', 'start_date'];
  dataSource: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private _apiService: ApiService, private router: Router) { }

  ngOnInit() {
    this.getbrandads();
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  // get brand ads
  getbrandads() {
    this._apiService.listtopbrandads('true').subscribe(
      res => {
        this.brandads = res;
        if (this.brandads.statuscode == 200) {
          this.dataSource = this.brandads.data;
        }
      },
      err => console.error(err)
    );
  }

}
