import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { ApiService } from 'src/app/core/services/api-service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-new-store',
  templateUrl: './new-store.component.html',
  styleUrls: ['./new-store.component.scss']
})
export class NewStoreComponent implements OnInit {
  public storeads;
  displayedColumns = ['sno', 'store_ad_name', 'store_offer'];
  dataSource: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private _apiService: ApiService, private router: Router) { }

  ngOnInit() {
    this.gettopstoreads();
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  // get store ads
  gettopstoreads() {
    this._apiService.listtopstoreads('true').subscribe(
      res => {
        this.storeads = res;
        if (this.storeads.statuscode == 200) {
          this.dataSource = this.storeads.data;
        }
      },
      err => console.error(err)
    );
  }

}
